using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Allure.Commons;
using Microsoft.Playwright;
using MilesBelgiumRIA.Drivers;
using NUnit.Framework;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Bindings;
// [assembly: Parallelizable(ParallelScope.Fixtures)]

namespace MilesBelgiumRIA.Hooks
{
    [Binding]
    public class Hooks
    {
        public readonly Context _context;
        public static AllureLifecycle Allure = AllureLifecycle.Instance;
        public Hooks(Context context) => _context = context;

        [BeforeTestRun]
        public static void InstallBrowsers()
        {
            Allure.CleanupResultDirectory();
            var exitCode = Microsoft.Playwright.Program.Main(new[] { "install" });
            if (exitCode != 0)
            {
                throw new Exception($"Playwright exited with code {exitCode}");
            }
        }

        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            var featureTitle = featureContext.FeatureInfo.Title;
            var featureDescription = featureContext.FeatureInfo.Description;
        }

        [BeforeScenario]
        public async Task Initialize()
        {
            var browserType = Environment.GetEnvironmentVariable("BROWSER_TYPE");
            // var browserType = "Chromium";
            _context.BrowserContext = await Driver.CreatePlaywright(
                browserType,
                new BrowserTypeLaunchOptions { Headless = false });
            await _context.BrowserContext.Tracing.StartAsync(new ()
            {
                Screenshots = true,
                Snapshots = true,
                Sources = true
            });
            _context.Page = await _context.BrowserContext.NewPageAsync();
        }

        private string CaptureScreenshot()
        {
            // Capture a screenshot and save it to a file
            string screenshotParent = Directory.GetCurrentDirectory();
            string rootFolder = Path.Combine(screenshotParent, @"..\..\..");
            string absolutePath = Path.GetFullPath(rootFolder);
            string screenshotDirectory = absolutePath + "/Reports/Screenshots";
            string screenshotFileName = $"screenshot_{DateTime.Now:yyyyMMdd_HHmmss}.png";
            string screenshotFilePath = Path.Combine(screenshotDirectory, screenshotFileName);

            // Assuming you have a reference to the currently open page
            var options = new PageScreenshotOptions { Path = screenshotFilePath };
            _context.Page.ScreenshotAsync(options).GetAwaiter().GetResult();

            return screenshotFilePath;
        }

        [AfterScenario]
        public async Task AfterScenario()
        {
            await _context.Page.CloseAsync();
            // var path = CaptureScreenshot();
            // string currentUtcTime = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            // var testName = TestContext.CurrentContext.Test.Name;
            // await _context.BrowserContext.Tracing.StopAsync(new()
            // {
            // Path = path
            // });
            // Allure.AddAttachment($"{testName}", "application/png", path);
        }
    }
}