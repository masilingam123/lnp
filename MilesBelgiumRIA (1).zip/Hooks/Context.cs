using Microsoft.Playwright;

namespace MilesBelgiumRIA.Hooks;

public class Context
{
    public IBrowserContext BrowserContext { get; set; }
    public IPage Page { get; set; }
}