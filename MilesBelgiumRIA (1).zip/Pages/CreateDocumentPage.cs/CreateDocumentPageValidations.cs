using System.IO;
using System.Threading.Tasks;
using MilesBelgiumRIA.Resources.Enums;
using NUnit.Framework;

namespace MilesBelgiumRIA.Pages.CreateDocumentPage;

public partial class CreateDocumentPage
{
    public void CheckDocumentFileExists(string filePath)
    {
        Assert.IsTrue(File.Exists(filePath));
        File.Delete(filePath);
    }

    public async Task CheckSuccessMessage(string expectedMessage)
    {
        var actualMessage = await GetText(MessageGrid(MessageGridType.Confirmation));
        Assert.AreEqual(expectedMessage, actualMessage);
    }
}