using MilesBelgiumRIA.Resources.Enums;

namespace MilesBelgiumRIA.Pages.CreateDocumentPage;

public partial class CreateDocumentPage
{
    private const string BaseXpath = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    public const string To = $"{BaseXpath}//label[text()='To']/ancestor::form/following-sibling::div//input";

    public string DocumentTemplatesItem(string itemText) => $"{BaseXpath}//div[contains(@eventproxy,'Document')]//tr[@role='treeitem']//div[text()='{itemText}']";

    public string ParametersInput(string label) => $"{BaseXpath}//div[contains(@eventproxy,'Parameters')]//label[text()='{label}']/ancestor::td//input";

    public string Button(string label) => $"{BaseXpath}//div[@role='button']//*[text()='{label}']";

    public string DocumentButton(string label) => $"{BaseXpath}//div[@role='button']//*[text()='{label}']/ancestor::td[@class='skinlessButton']";

    public string MessageGrid(MessageGridType msgType) => $"{BaseXpath}//td[contains(@class,'{msgType}_both')]/div";
}