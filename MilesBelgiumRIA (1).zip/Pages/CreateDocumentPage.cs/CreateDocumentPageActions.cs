using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Utils;

namespace MilesBelgiumRIA.Pages.CreateDocumentPage;

public partial class CreateDocumentPage : BasePage
{
    private readonly RandomUtils randomUtils;
    private readonly FileUtils fileUtils;
    public CreateDocumentPage(Context context, RandomUtils randomUtils, FileUtils fileUtils) : base(context)
    {
        this.randomUtils = randomUtils;
        this.fileUtils = fileUtils;
    }

    public async Task SelectTemplate(string itemText)
    {
        await ClickElement(DocumentTemplatesItem(itemText));
    }

    public async Task SelectStrategy(string strategy)
    {
        await ClickElement(ParametersInput("Strategy"), true);
        await EnterText(ParametersInput("Strategy"), "");
        await Type(ParametersInput("Strategy"), strategy);
        await SendKeys("Enter");
    }

    public async Task ClickNext()
    {
        await ClickElement(Button("Next"));
    }

    public async Task<string> ClickPreview()
    {
        return await fileUtils.WaitForDownloadAndSaveFile(Button("Preview"), ".pdf");
    }

    public async Task ClickCancel()
    {
        await ClickElement(Button("Cancel"));
    }

    public async Task ClickDocumentCancelButton()
    {
        await ClickElement(DocumentButton("Cancel"));
    }

    public async Task<string> ClickDownload()
    {
        return await fileUtils.WaitForDownloadAndSaveFile(Button("Download"), ".pdf");
    }

    public async Task ClickMail()
    {
        await ClickElement(Button("Mail"));
    }

    public async Task SetEmailRecipient(string emailRecipient)
    {
        await ClickElement(To);
        await SendKeys("Backspace");
        await SendKeys("Backspace");
        await SendKeys("Backspace");
        await Type(To, emailRecipient);
        await SendKeys("Enter");
    }
}