namespace MilesBelgiumRIA.Pages.ObjectPage;

public partial class ObjectPage
{
    private const string BaseXpath = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    private string BasePopUp(string popUpName) => $"//div[contains(@eventproxy,'{popUpName}')]";

    public string ObjectRibbonBarButton(string buttonName) => $"{BaseXpath}//div[@role='button']//table/descendant-or-self::*[text()='{buttonName}']";

    public string CheckBoxProspect(string text) => $"{BaseXpath}//div[@class='staticTextItem']//tbody//td[text()='{text}']/../td/img[@class='silkCheckboxImg']";

    public string InputTextBox(string label) => $"{BaseXpath}//label[text()='{label}']/ancestor::td//input";

    public string InputTextBoxPerson(string label) => $"//label[text()='{label}']/ancestor::td//input[@id= isc_16R']";

    public string InputTextBoxLanguage(string label) => $"//label[text()='{label}']/ancestor::td//input[@id='isc_18X']";

    public string InputTextBoxGeneric(string menu, string label) => $"//div[@class='{menu}']//label[text()='{label}']/ancestor::td//input";

    public string InputTextBoxContract(string menu, string label) => $"//div[text()='{menu}']/ancestor::div[@role='tablist']//label[text()='{label}']/ancestor::td//input";

    public string InputTextBoxImg(string menu, string label) => $"//div[text()='{menu}']/ancestor::div[@role='tablist']//label[text()='{label}']/ancestor::td//input//../..//img";

    public string InputTextBoxPopUp(string popUpName, string label) => $"{BaseXpath}{BasePopUp(popUpName)}//label[text()='{label}']/ancestor::td//input";

    public string TextArea(string label) => $"{BaseXpath}//label[text()='{label}']/ancestor::td//textarea";

    public string GridLine(string position) => $"{BaseXpath}//div[@class='silkListGrid']//tr[@aria-posinset='{position}']";

    public string PageSideMenu(int level, string menu) => $"{BaseXpath}//tr[@role='treeitem' and @aria-level='{level}']//div[text()='{menu}']";

    public string GridCell(string name, int row, int column) => $"{BaseXpath}//div[text()='{name}']/ancestor::div[@class='sectionStack']//div[@class='silkListGrid']//tr[{row}]/td[{column}]";

    public string GridCellInput(string name, int row, int column) => $"{GridCell(name, row, column)}//input";

    public string GridDocuments(string position) => $"{BaseXpath}//div[@id='isc_1LG']//tr[@aria-posinset='{position}']";

    public string GenericButton(string label) => $"{BaseXpath}//div[@aria-label='{label}']//img";

    public string PopUpButton(string label) => $"//div[@aria-label='{label}']";

    public string PopUpButtonContract(string popUpName, string label) => $"{BaseXpath}{BasePopUp(popUpName)}//div[@aria-label='{label}']";

    public string PopUpGrid(string label) => $"{BaseXpath}//div[text()='{label}']";

    public string PopUpCheckBox(string label) => $"{BaseXpath}//td[text()='{label}']";

    public string ContactDetailsButton(string name) => $"//div[span='{name}']";

    public string AddButton(string sectionLabel) => $"//div[text()='{sectionLabel}']/ancestor::div[@aria-label='{sectionLabel}']//div[contains(@aria-label,'Add')]";

    public string RemoveButton(string sectionLabel) => $"//div[text()='{sectionLabel}']/ancestor::div[@aria-label='{sectionLabel}']//div[contains(@aria-label,'Remove (Alt+Del)')]";

    public string GridInput(string gridName, int inputName) => $"//div[@eventproxy='{gridName}']//tr[@role='listitem']/td[{inputName}]//input";

    public string GridField(string gridName, int inputName) => $"//div[@eventproxy='{gridName}']//tr[@role='listitem']/td[{inputName}]";

    public string GridEmailLine = "//div[@eventproxy='id_sectionstack_InternetDetails_5']//div[text()='E-mail']";
    public string VersionButton = "//span[text()='VWBE CONS DE (VWBE CONS DE)']";
    public string AddressGrid = "grid_BusinessCardAddressEditorGrid_1";
    public string AddressGrid2 = "grid_BusinessCardAddressEditorGrid_2";
    public string PhoneNumberGrid = "id_sectionstack_PhoneNumbers_1";
    public string PhoneNumberGrid2 = "grid_BusinessCardPhoneNrEditor_2";
    public string PhoneNumberGridPrivatePerson = "grid_BusinessCardPhoneNrEditor_1_body";
    public string InternetDetailsGrid = "id_sectionstack_InternetDetails_1";
    public string InternetDetailsGrid2 = "grid_BusinessCardInternetReferenceEditor_2";
    public string InternetDetailsPP = "id_sectionstack_InternetDetails_5";
    public string LanguageBox = "//input[@id='isc_9Z0']";
    public string ActivateDocument = "//td[@class='iconButton']//span[text()='Activate']";
}