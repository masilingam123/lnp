using System;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Playwright;
using NUnit.Framework;

namespace MilesBelgiumRIA.Pages.ObjectPage;

public partial class ObjectPage
{
    public async Task CheckInputFieldNotEmpty(string fieldLabel, int maxWait = 20000)
    {
        string fieldContent = await ReadInputValue(InputTextBox(fieldLabel), maxWait);
        Assert.IsNotEmpty(fieldContent);
    }

    public async Task CheckTextAreaFieldNotEmpty(string fieldLabel, int maxWait = 20000)
    {
        string fieldContent = await ReadInputValue(TextArea(fieldLabel), maxWait);
        Assert.IsNotEmpty(fieldContent);
    }

    public async Task CheckFieldContent(string fieldLabel, string expectedContent, int maxWait = 40000)
    {
        string fieldContent = await WaitForValueToMatch(InputTextBox(fieldLabel), maxWait, expectedContent);
        Assert.AreEqual(expectedContent, fieldContent);
    }

    public async Task CheckFieldContentContract(string menu, string fieldLabel, string expectedContent, int maxWait = 40000)
    {
        string fieldContent = await WaitForValueToMatch(InputTextBoxContract(menu, fieldLabel), maxWait, expectedContent);
        Assert.AreEqual(expectedContent, fieldContent);
    }

    public async Task CheckHistoryStatusIs(string expectedStatus, int numberOfRows)
    {
        for (int i = 1; i < numberOfRows; i++)
        {
            Assert.AreEqual(expectedStatus, await ReadCellValue("History", i, 4));
        }
    }

    public async Task CheckTheJobRunsEvery(int expectedMinutes, int numberOfRows)
    {
        for (int i = 2; i < numberOfRows; i++)
        {
            var currDate = dateUtils.ConvertToDateTime(await ReadCellValue("History", i, 2));
            var prevDate = dateUtils.ConvertToDateTime(await ReadCellValue("History", i - 1, 2));
            var diff = dateUtils.SubtractDate(prevDate, currDate).Minutes;
            diff.Should().BeCloseTo(expectedMinutes, 1);
        }
    }

    public async Task CheckTheJobsRunEveryBusinessDay(int numberOfRows)
    {
        var currDay = DateTime.Now.ToString("dd/MM/yyyy");
        var lastDay = dateUtils.ConvertToDateTime(await ReadCellValue("History", 1, 2)).ToString("dd/MM/yyyy");
        Assert.AreEqual(currDay, lastDay);

        for (int i = 2; i < numberOfRows; i++)
        {
            // Get dates
            var currDate = dateUtils.ConvertToDateTime(await ReadCellValue("History", i, 2)).ToString("dd/MM/yyyy");
            var prevDate = dateUtils.ConvertToDateTime(await ReadCellValue("History", i - 1, 2)).ToString("dd/MM/yyyy");

            // Ignore time component
            DateTime currConvertedDate = DateTime.ParseExact(currDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            DateTime prevConvertedDate = DateTime.ParseExact(prevDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            // Calculate diff
            var diff = dateUtils.GetBusinessDays(currConvertedDate, prevConvertedDate);
            diff.Should().Be(2, "The jobs runs every business day");
        }
    }

    public async Task CheckFileContainsDate(string filePath, DateTime expectedDate)
    {
        var text = await File.ReadAllTextAsync(filePath);
        var year = expectedDate.Year;
        var month = expectedDate.ToString("MM");
        var day = expectedDate.ToString("dd");
        var stringToCheck = year + "-" + month + "-" + day; // 2022-12-04
        var contains = text.Contains(stringToCheck);
        contains.Should().Be(true);
    }

    public async Task CheckCustomerCreation(ILocator element)
    {
        bool isVisible = await element.IsVisibleAsync();
        bool isEnabled = await element.IsEnabledAsync();

        Assert.IsTrue(isVisible, "The element is not visible.");
        Assert.IsTrue(isEnabled, "The element is disabled.");
    }

    public async Task CheckCustomerProspect()
    {
        var customerClassification = GetElementHandle(InputTextBox("Overrule Customer Classification"));
        string inputValue = await customerClassification.EvaluateAsync<string>("input => input.value");
        Assert.IsTrue(string.IsNullOrEmpty(inputValue), "A value is selected in the dropdown.");
    }

    private async Task<string> WaitForValueToMatch(string selector, int maxWait, string expectedValue)
    {
        double itrNumber = maxWait / 1000;
        string fieldContent = string.Empty;

        for (int i = 0; i < Math.Ceiling(itrNumber); i++)
        {
            fieldContent = await GetElementProperty(selector, "value");
            if (fieldContent == expectedValue)
            {
                break;
            }
            else
            {
                Thread.Sleep(1000);
            }
        }

        return fieldContent;
    }
}