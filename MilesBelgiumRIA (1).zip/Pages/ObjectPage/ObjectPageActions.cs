using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Utils;

namespace MilesBelgiumRIA.Pages.ObjectPage;

public partial class ObjectPage : BasePage
{
    private readonly Common common;
    private readonly DateUtils dateUtils;
    private readonly FileUtils fileUtils;
    private readonly RandomUtils randomUtils;
    private readonly IPage _page;

    public ObjectPage(Context context, Common common, DateUtils dateUtils, FileUtils fileUtils, RandomUtils randomUtils) : base(context)
    {
        this.common = common;
        this.dateUtils = dateUtils;
        this.fileUtils = fileUtils;
        this.randomUtils = randomUtils;
        _page = context.Page;
    }

    public async Task SendKeysPopUp(string key)
    {
        await SendKeys(key);
    }

    public async Task ClickRibbonBarButton(string buttonName)
    {
        await ClickElement(ObjectRibbonBarButton(buttonName));
    }

    public ILocator GetElementHandle(string locator)
    {
        var elementHandle = _page.Locator(locator);
        return elementHandle;
    }

    public async Task ClickGridCell(string name, int row, int column)
    {
        await ClickElement(GridCell(name, row, column));
    }

    public async Task ClickVersionButton()
    {
        await ClickElement(VersionButton, true);
    }

    public async Task ClickActivateButton()
    {
        await ClickElement(ActivateDocument, true);
    }

    public async Task DoubleClickGridCell(string name, int row, int column)
    {
        await DoubleClickElement(GridCell(name, row, column));
    }

    public async Task ClickGenericButton(string label)
    {
        await ClickElement(GenericButton(label), true);
    }

    public async Task ClickPopUpButton(string label)
    {
        await ClickElement(PopUpButton(label), true);
    }

    public async Task ClickPopUpCheckBox(string label)
    {
        await ClickElement(PopUpCheckBox(label), true);
    }

    public async Task ClickPopUpButtonContract(string popUpName, string label)
    {
        await ClickElement(PopUpButtonContract(popUpName, label), true);
    }

    public async Task ClickPopUpGrid(string label)
    {
        await ClickElement(PopUpGrid(label), true);
    }

    public async Task DoubleClickPopUpGrid(string label)
    {
        await DoubleClickElement(PopUpGrid(label));
    }

    public async Task ClickAddButton(string name)
    {
        await ClickElement(AddButton(name), true);
    }

    public async Task ClickContactDetailsButton(string name)
    {
        await ClickElement(ContactDetailsButton(name), true);
    }

    public async Task ClickRemoveButton(string name)
    {
        await ClickElement(RemoveButton(name), true);
    }

    public async Task SetInputFieldValue(string label, string text)
    {
        await ClickElement(InputTextBox(label));
        await EnterText(InputTextBox(label), "");
        await Type(InputTextBox(label), text);
        await SendKeys("Tab");
    }

    public async Task SetInputFieldPerson(string label, string text)
    {
        await ClickElement(InputTextBoxPerson(label));
        await EnterText(InputTextBoxPerson(label), "");
        await Type(InputTextBoxPerson(label), text);
        await SendKeys("Enter");
    }

    public async Task SetInputFieldKeyContact()
    {
        await _page.Locator("form").Filter(new () { HasTextString = "TitleFirst NameLast NameGenderNationality" }).GetByLabel("Title").ClickAsync();
        await _page.Locator("form").Filter(new () { HasTextString = "TitleFirst NameLast NameGenderNationality" }).GetByLabel("Title").FillAsync("mrs");
    }

    public async Task SetInputFieldLanguage(string label, string text)
    {
        await ClickElement(InputTextBoxLanguage(label));
        await EnterText(InputTextBoxLanguage(label), "");
        await Type(InputTextBoxLanguage(label), text);
        await SendKeys("Enter");
    }

    public async Task SetInputFieldValueGeneric(string menu, string label, string text)
    {
        await ClickElement(InputTextBoxGeneric(menu, label));
        await EnterText(InputTextBoxGeneric(menu, label), "");
        await Type(InputTextBoxGeneric(menu, label), text);
        await SendKeys("Enter");
    }

    public async Task SetInputFieldValue_Tab(string popUpName, string label, string text)
    {
        await ClickElement(InputTextBoxPopUp(popUpName, label));
        await EnterText(InputTextBoxPopUp(popUpName, label), "");
        await Type(InputTextBoxPopUp(popUpName, label), text);
        await SendKeys("Tab");
    }

    public async Task SetInputFieldValueGrid(string name, int row, int column, string text)
    {
        await ClickElement(GridCellInput(name, row, column));
        await EnterText(GridCellInput(name, row, column), "");
        await Type(GridCellInput(name, row, column), text);
        await SendKeys("Enter");
    }

    public async Task SetInputFieldValueContract(string menu, string label, string text)
    {
        await ClickElement(InputTextBoxContract(menu, label));
        await EnterText(InputTextBoxContract(menu, label), "");
        await Type(InputTextBoxContract(menu, label), text);
        await SendKeys("Enter");
    }

    public async Task SelectTotalDuration(string text)
    {
        await ClickElement(InputTextBoxContract("New Version", "Total Duration"), true);
        await EnterText(InputTextBoxContract("New Version", "Total Duration"), "");
        await Type(InputTextBoxContract("New Version", "Total Duration"), text);
    }

    public async Task SelectTotalDistance(string text)
    {
        await DoubleClickElement(InputTextBoxContract("New Version", "Total Distance"));
        Thread.Sleep(2000);
        await EnterText(InputTextBoxContract("New Version", "Total Distance"), "");
        await Type(InputTextBoxContract("New Version", "Total Distance"), text);
    }

    public async Task SetInputFieldLicensePlate(string menu, int row, int column)
    {
        await SetInputFieldValueGrid(menu, row, column, $"9-{randomUtils.GenerateRandomString(3)}-{randomUtils.GenerateRandomNumber(3)}");
    }

    public async Task SetDropDownValue(string label, string itemName)
    {
        await ClickElement(InputTextBox(label));
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetDropDownLanguage(string itemName)
    {
        await ClickElement(LanguageBox);
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetDropDownValueGrid(string position, string itemName)
    {
        await ClickElement(GridLine(position));
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetDropDownFieldGrid(string menu, int row, int column, string itemName)
    {
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetDropDownValueContract(string menu, string label, string itemName)
    {
        await ClickElement(InputTextBoxContract(menu, label), true);
        await ClickElement(InputTextBoxImg(menu, label), true);
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetDocuments(string dropDownText) // string valueToReplace)
    {
        await ChangeMultipleDropDownValues(dropDownText); // valueToReplace);
    }

    public async Task SetDropDownInsidePopUp(string popUpName, string label, string itemName)
    {
        await ClickElement(InputTextBoxPopUp(popUpName, label));
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetInputInsidePopUp(string popUpName, string label, string itemName)
    {
        await ClickElement(InputTextBoxPopUp(popUpName, label));
        await Type(InputTextBoxPopUp(popUpName, label), itemName);
    }

    public async Task SetGridAddress(int inputName, string textInput)
    {
        await ClickElement(GridInput(AddressGrid, inputName));
        await Type(GridInput(AddressGrid, inputName), textInput);
    }

    public async Task SetGridAddress2(int inputName, string textInput)
    {
        await ClickElement(GridInput(AddressGrid2, inputName));
        await Type(GridInput(AddressGrid2, inputName), textInput);
    }

    public async Task ClickGridAddress(int inputName)
    {
        await ClickElement(GridField(AddressGrid, inputName));
    }

    public async Task SetGridPhoneNumber(int inputName, string textInput)
    {
        await ClickElement(GridInput(PhoneNumberGrid, inputName));
        await Type(GridInput(PhoneNumberGrid, inputName), textInput);
    }

    public async Task SetGridPhoneNumber2(int inputName, string textInput)
    {
        await ClickElement(GridInput(PhoneNumberGrid2, inputName));
        await Type(GridInput(PhoneNumberGrid2, inputName), textInput);
    }

    public async Task ClickPhoneGridLine()
    {
        await _page.GetByText("Belgium").Nth(1).ClickAsync();
    }

    public async Task SetGridInternetDetails(int inputName, string textInput)
    {
        await ClickElement(GridInput(InternetDetailsGrid, inputName));
        await Type(GridInput(InternetDetailsGrid, inputName), textInput);
    }

    public async Task SetGridInternetDetails2(int inputName, string textInput)
    {
        await ClickElement(GridInput(InternetDetailsGrid2, inputName));
        await Type(GridInput(InternetDetailsGrid2, inputName), textInput);
    }

    public async Task SetGridInternetDetailsPP(string textInput)
    {
        // await ClickElement(GridField(InternetDetailsPP, inputName));
        // await Type(GridInput(InternetDetailsPP, inputName), textInput);
        await _page.Locator("#isc_1BLtable").GetByText("E-mail").ClickAsync();
        await _page.Locator("input[name=\"A340\"]").PressAsync("Tab");
        await _page.Locator("input[name=\"A22\"]").FillAsync(textInput);

        // await page.Locator("#isc_1BLtable td").Nth(1).ClickAsync();
        // await page.Locator("input[name=\"A22\"]").FillAsync(textInput);
    }

    public async Task ClickEmailLine()
    {
        await ClickElement(GridEmailLine);
    }

    public async Task SetDropDownGrid(string itemName)
    {
        await ClickElement(common.DropDownSelectItem(itemName));
    }

    public async Task SetSupplierRole()
    {
        await _page.Locator("#silkMultiLink_R6_1_widget div").Filter(new () { HasTextString = "Supplier" }).Nth(2).ClickAsync();
        await _page.Locator("#id_R6_1_1 div").Nth(1).ClickAsync();
        await _page.Locator("//div[text()='Dealer']").ClickAsync();
        await _page.GetByRole(AriaRole.Button, new () { NameString = "OK" }).ClickAsync();
    }

    public async Task SetCustomerRole()
    {
        await _page.Locator("#silkMultiLink_R6_1_widget div").Filter(new () { HasTextString = "Customer" }).Nth(2).ClickAsync();
        await _page.Locator("#id_R6_1_1 div").Nth(1).ClickAsync();
        await _page.Locator("//div[text()='VDFIN']").ClickAsync();
        await _page.GetByRole(AriaRole.Button, new () { NameString = "OK" }).ClickAsync();
    }

    public async Task SetKeyContactRole()
    {
        await _page.Locator("#id_theContactRolesForContactLinks_1_2 input[type=\"text\"]").ClickAsync();
        await _page.Locator("#id_theContactRolesForContactLinks_1_2 div").Nth(1).ClickAsync();
        await _page.Locator("//div[text()='Key Contact']").ClickAsync();
        await _page.GetByRole(AriaRole.Button, new () { NameString = "OK" }).ClickAsync();
    }

    public async Task SetCustomerRolePP()
    {
        await _page.Locator("#id_R6_3_1").GetByRole(AriaRole.Textbox).ClickAsync();
        await _page.Locator("#id_R6_3_1 div").Nth(1).ClickAsync();
        await _page.GetByText("VDFIN").ClickAsync();
        await _page.GetByRole(AriaRole.Button, new () { NameString = "OK" }).ClickAsync();
    }

    public async Task SetPartnerLabels()
    {
        await _page.Locator("#silkMultiLink_theLabelLinks_1_widget > .silkTextItem > div:nth-child(3) > div").ClickAsync();
        await _page.Locator("#id_theLabelLinks_1_1 div").Nth(1).ClickAsync();
        await _page.Locator("//div[@class='windowBackground']//div[@class='windowBody']//div[text()='VDFIN']").ClickAsync();
        await _page.Locator("//div[@aria-label='OK']//img").ClickAsync();
        await _page.Locator("//div[@aria-label='Close']//img").ClickAsync();
    }

    public async Task SetPartnerLabelsPP()
    {
        await _page.Locator("#id_theLabelLinks_3_1").GetByRole(AriaRole.Textbox).ClickAsync();
        await _page.Locator("#id_theLabelLinks_3_1 div").Nth(1).ClickAsync();
        await _page.Locator("//div[@class='windowBackground']//div[@class='windowBody']//div[text()='VDFIN']").ClickAsync();
        await _page.Locator("//div[@aria-label='OK']//img").ClickAsync();
    }

    public async Task SetLanguage()
    {
        await _page.GetByRole(AriaRole.Textbox, new () { NameString = "Language" }).ClickAsync();
        await _page.GetByRole(AriaRole.Cell, new () { NameString = "Dutch" }).Locator("div").ClickAsync();
    }

    public async Task ClickSideMenu(int level, string menu)
    {
        await ClickElement(PageSideMenu(level, menu));
    }

    public async Task<string> ReadCellValue(string gridName, int row, int column)
    {
        return await GetText(GridCell(gridName, row, column));
    }

    public async Task<string> ReadInputValue(string selector, int maxWait = 10000)
    {
        double itrNumber = maxWait / 1000;
        string fieldContent = string.Empty;

        for (int i = 0; i < Math.Ceiling(itrNumber); i++)
        {
            fieldContent = await GetElementProperty(selector, "value");
            if (fieldContent != string.Empty)
            {
                break;
            }
            else
            {
                Thread.Sleep(1000);
            }
        }

        return fieldContent;
    }

    public async Task<string> ClickLogResultAndWaitForDownload()
    {
        return await fileUtils.WaitForDownloadAndSaveFile(ObjectRibbonBarButton("Result"), ".txt");
    }

    public async Task WaitForFlexMatrix(string selector, string label, int maxWait = 40000)
    {
        for (int i = 0; i < 180; i++) // 180*20/60 = 1hr
        {
            await ClickElement(ObjectRibbonBarButton(selector));
            var text = await ReadInputValue(InputTextBox(label));
            if (text == "Yes")
            {
                break;
            }
            else
            {
                Thread.Sleep(20000);
            }
        }
    }
}