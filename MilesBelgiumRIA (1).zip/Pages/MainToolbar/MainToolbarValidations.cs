using System;
using System.Threading.Tasks;
using FluentAssertions;

namespace MilesBelgiumRIA.Pages.HomePage;

public partial class MainToolbar
{
    public async Task TheUserNameShoulBeTopOfThePage(string expextedUser)
    {
        var actualText = await GetUserLogged();
        var expextedText = "Logged on as " + Environment.GetEnvironmentVariable(expextedUser);
        actualText.Should().Be(expextedText);
    }

    public async Task UserNameShouldBeVisible()
    {
        var actualText = await GetUserIsLogged();
        var expextedText = "Driver, LnP";
        actualText.Should().Be(expextedText);
    }

    public async Task UserNameShouldBeOnThePage()
    {
        var actualText = await GetUserIsLoggedIn();
        var expextedText = "Fleet Manager, LnP";
        actualText.Should().Be(expextedText);
    }
}