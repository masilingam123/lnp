namespace MilesBelgiumRIA.Pages.HomePage;

public partial class MainToolbar
{
    public const string UserLogged = "//span[contains(text(),'Logged on as')]";

    public const string UserLoggedMMPDriver = "//a[@class='dropdown-toggle nav-link']//span[text()='Driver, LnP']";

    public const string UserLoggedMMPFM = "//a[@class='dropdown-toggle nav-link']//span[text()='Fleet Manager, LnP']";

    public const string QuickNavigation = "//input[@id='sofid_id_quicknavigation_field']";
}