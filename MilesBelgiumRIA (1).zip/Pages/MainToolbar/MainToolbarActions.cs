using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Resources.Enums;

namespace MilesBelgiumRIA.Pages.HomePage;

public partial class MainToolbar : BasePage
{
    public MainToolbar(Context context) : base(context)
    {
    }

    public async Task<string> GetUserLogged()
    {
        return await GetText(UserLogged);
    }

    public async Task<string> GetUserIsLogged()
    {
        return await GetText(UserLoggedMMPDriver);
    }

    public async Task<string> GetUserIsLoggedIn()
    {
        return await GetText(UserLoggedMMPFM);
    }

    public async Task QuickNavigationSearch(string objectType, QuickBarSelect select, int waitDuration = 1000)
    {
        Thread.Sleep(waitDuration);
        await ClickElement(QuickNavigation);
        await Type(QuickNavigation, objectType);
        Thread.Sleep(2000);
        await SendKeys("Enter");
        await SendKeys("ArrowDown");
        await SendKeys("Enter");

        switch (select)
        {
            case QuickBarSelect.Search:
            {
                await SendKeys("ArrowDown");
                await SendKeys("Enter");
                break;
            }

            case QuickBarSelect.New:
            {
                await SendKeys("ArrowDown");
                await SendKeys("ArrowDown");
                await SendKeys("Enter");
                break;
            }

            case QuickBarSelect.Direct:
                break;
        }
    }
}