using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MilesBelgiumRIA.Pages.CommonPage;

public partial class Common : BasePage
{
    public Common(Context context) : base(context)
    {
    }

    public async Task GotoWebPage(string siteValue)
    {
        var sitesData = File.ReadAllText("../../../Test Data/Environments/site.json");
        var site = JObject.Parse(sitesData)[siteValue].ToString();
        await Navigate(site);
    }

    public static Dictionary<string, string> CreateDictionaryFromJsonFile(string folder, string fileName)
    {
        var jsonFile = File.ReadAllText($"../../../Test Data/{folder}/{fileName}.json");
        // Convert jsonFile to a dictionary
        Dictionary<string, string> data = JsonConvert.DeserializeObject<Dictionary<string, string>>(jsonFile);
        return data;
    }

    public static Dictionary<string, Dictionary<string, string>> ReadJsonFileAsDictionary(string folder, string fileName)
    {
        var jsonFile = File.ReadAllText($"../../../Test Data/{folder}/{fileName}.json");
        Dictionary<string, Dictionary<string, string>> data = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(jsonFile);
        return data;
    }
}