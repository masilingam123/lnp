using MilesBelgiumRIA.Pages.BasePages;

namespace MilesBelgiumRIA.Pages.CommonPage;

public partial class Common : BasePage
{
    public string DropDownSelectItem(string itemName) => $"//table[contains(@id,'table')]//tr[@role='listitem']//span[text()='{itemName}']";
}