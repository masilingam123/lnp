using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;

namespace MilesBelgiumRIA.Pages.BasePages;

public class BasePage
{
    private readonly IBrowserContext _contextBrowser;
    private readonly IPage _page;
    public BasePage(Context context)
    {
        _contextBrowser = context.BrowserContext;
        _page = context.Page;
    }

    public async Task Navigate(string pageURL)
    {
        await _page.GotoAsync(pageURL);
    }

    public async Task ClickElement(string selector, bool force = false)
    {
        await _page.Locator(selector).ClickAsync(new () { Force = force });
        await WaitForLoadingToBeHidden();
    }

    public async Task ClickNthElement(string selector, int elementNth, bool force = false)
    {
        await _page.Locator(selector).Nth(0).ClickAsync(new () { Force = force });
        await WaitForLoadingToBeHidden();
    }

    public async Task DoubleClickElement(string selector)
    {
        await _page.Locator(selector).DblClickAsync();
        await WaitForLoadingToBeHidden();
    }

    public async Task EnterText(string selector, string text, int waitDuration = 500)
    {
        await _page.Locator(selector).FillAsync(text);
        Thread.Sleep(waitDuration);
    }

    public async Task EnterNthText(string selector, int elementNth, string text, int waitDuration = 500)
    {
        await _page.Locator(selector).Nth(0).FillAsync(text);
        Thread.Sleep(waitDuration);
    }

    public async Task Type(string selector, string text, int waitDuration = 500)
    {
        await _page.Locator(selector).TypeAsync(text, new () { Delay = 100 });
        Thread.Sleep(waitDuration);
    }

    public async Task TypeNth(string selector, int elementNth, string text, int waitDuration = 500)
    {
        await _page.Locator(selector).Nth(0).TypeAsync(text, new () { Delay = 100 });
        Thread.Sleep(waitDuration);
    }

    public async Task SendKeys(string key)
    {
        await _page.Keyboard.DownAsync(key);
        await WaitForLoadingToBeHidden();
    }

    public async Task<string> GetText(string selector)
    {
        return await _page.Locator(selector).InnerTextAsync();
    }

    public async Task WaitForLoadingToBeHidden()
    {
        await _page.GetByText("Loading...").WaitForAsync(new ()
        {
            State = WaitForSelectorState.Hidden,
            Timeout = 60000
        });
    }

    public async Task<string> GetElementProperty(string selector, string propName)
    {
        var element = _page.Locator(selector);
        var value = await element.EvaluateAsync($"node => node.{propName}");
        return value.ToString();
    }

    public async Task<IDownload> ClickAndWaitForDownload(string buttonSelector)
    {
        var download = await _page.RunAndWaitForDownloadAsync(async () =>
        {
            await _page.Locator(buttonSelector).ClickAsync();
        });
        System.Console.WriteLine(await download.PathAsync());
        return download;
    }

    public async Task ChangeMultipleDropDownValues(string dropDownText) // string valueToReplace)
    {
        var nr = await _page.GetByText(dropDownText).CountAsync();
        for (int i = 2; i < nr; i++)
        {
            await _page.GetByText(dropDownText).First.ClickAsync();
            // await _page.Keyboard.InsertTextAsync(valueToReplace);
            await _page.Locator("#isc_378").GetByRole(AriaRole.Button).ClickAsync();
            await _page.Locator("#isc_38Ltable").GetByText("Received").ClickAsync();
            await _page.Keyboard.DownAsync("Enter");
        }
    }

    public ILocator GetElementByText(string text)
    {
        return _page.GetByText(text);
    }
}