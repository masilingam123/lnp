using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Utils;

namespace MilesBelgiumRIA.Pages.TabBarPage;

public partial class TabBarPage : BasePage
{
    private readonly RandomUtils randomUtils;
    private readonly Common common;
    public TabBarPage(Context context, RandomUtils randomUtils, Common common) : base(context)
    {
        this.randomUtils = randomUtils;
        this.common = common;
    }

    public async Task ClickTabBar(string name)
    {
        await ClickElement(TabBar(name), true);
    }
}
