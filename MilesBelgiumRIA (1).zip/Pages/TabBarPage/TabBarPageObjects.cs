namespace MilesBelgiumRIA.Pages.TabBarPage;

public partial class TabBarPage
{
    public string TabBar(string name) => $"//div[@class='tabBarBottom']//div[text()='{name}']";
}