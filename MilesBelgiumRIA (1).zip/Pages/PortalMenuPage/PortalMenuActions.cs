using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using NUnit.Framework;

namespace MilesBelgiumRIA.Pages.PortalMenuPage;

public partial class PortalMenuPage : BasePage
{
    private readonly Common common;

    public PortalMenuPage(Context context, Common common) : base(context)
    {
        this.common = common;
    }

    public async Task SelectMenu(string menuName)
    {
        await ClickNthElement(PortalTitle(menuName), 1);
        Thread.Sleep(2000);
    }

    public async Task ClickHome()
    {
        await ClickElement(HomeMenu, true);
    }
}