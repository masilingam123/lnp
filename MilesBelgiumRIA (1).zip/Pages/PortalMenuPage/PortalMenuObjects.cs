namespace MilesBelgiumRIA.Pages.PortalMenuPage;

public partial class PortalMenuPage
{
    public string PortalTitle(string menuName) => $"//td[contains(@class,'portal')]//span[text()='{menuName}']";

    public string TabPortalMenu = "//td[@class='pageTitleLarge']";

    public string HomeMenu = "//td[@class='breadCrumb' and text()='Home']";
}