using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using NUnit.Framework;

namespace MilesBelgiumRIA.Pages.PortalMenuPage;

public partial class PortalMenuPage
{
    public void ValidatePortalMenu(string expected, string actual)
    {
        // var expWithPrefix = "Miles - " + expected;
        // Assert.AreEqual(expWithPrefix, actual);
        Assert.AreEqual(expected, actual);
    }

    public async Task<string> ReadPortalName()
    {
        return await GetText(TabPortalMenu);
    }
}