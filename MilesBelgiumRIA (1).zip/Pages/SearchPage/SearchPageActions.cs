using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Utils;

namespace MilesBelgiumRIA.Pages.SearchPage;

public partial class SearchPage : BasePage
{
    private readonly RandomUtils randomUtils;
    private readonly Common common;
    public SearchPage(Context context, RandomUtils randomUtils, Common common) : base(context)
    {
        this.randomUtils = randomUtils;
        this.common = common;
    }

    public async Task ClickSearchButton()
    {
        await ClickElement(SearchButton);
    }

    public async Task ClickRandomResultItem()
    {
        var rndNr = randomUtils.GenerateRandomNumber(1, 100);
        await DoubleClickElement(ResultListItem(rndNr));
    }

    public async Task ClickResultItem(int itemPosition)
    {
        await DoubleClickElement(ResultListItem(itemPosition));
    }

    public async Task ClickSearchResulstButton(string buttonName)
    {
        await ClickElement(SearchResultsButton(buttonName));
    }

    public async Task SetInputFieldValue(string label, string text)
    {
        await EnterText(ConditionInputBox(label), text, 0);
    }

    public async Task SetInputField(string label, string text)
    {
        await ClickElement(ConditionInputBox(label));
        await EnterText(ConditionInputBox(label), "");
        await Type(ConditionInputBox(label), text);
        await SendKeys("Enter");
    }

    public async Task SetInputConditionSign(string label, string text)
    {
        await ClickElement(ConditionInputSign(label));
        await EnterText(ConditionInputSign(label), "");
        await Type(ConditionInputSign(label), text);
        await SendKeys("Tab");
    }

    public async Task SetInputFieldNth(string label, string text)
    {
        await ClickNthElement(ConditionInputBox(label), 1);
        await EnterNthText(ConditionInputBox(label), 1, "");
        await TypeNth(ConditionInputBox(label), 1, text);
        await SendKeys("Enter");
    }

    public async Task SetInputFieldTab(string label, string text)
    {
        await ClickElement(ConditionInputBox(label));
        await EnterText(ConditionInputBox(label), "");
        await Type(ConditionInputBox(label), text);
        await SendKeys("Tab");
    }

    public async Task SetMultiSelectionField(string label, string[] items)
    {
        await ClickElement(ConditionInputBox(label));
        foreach (var item in items)
        {
            await ClickElement(common.DropDownSelectItem(item));
        }
    }

    public async Task SetSelectionQuery(string queryName)
    {
        await ClickElement(SelectionQuery);
        await EnterText(SelectionQuery, "");
        await Type(SelectionQuery, queryName);
        await SendKeys("Enter");
    }
}