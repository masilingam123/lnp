namespace MilesBelgiumRIA.Pages.SearchPage;

public partial class SearchPage
{
    private const string BaseXpath = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    public const string SearchButton = $"{BaseXpath}//td[text()='Search']";

    public const string SelectionQuery = $"{BaseXpath}//input[@name='selection']";

    public string ConditionInputBox(string label) => $"{BaseXpath}//span[text()=' {label}']/ancestor::tr//input[@name='silk_search_condValue']";

    public string ConditionInputSign(string label) => $"{BaseXpath}//span[text()=' {label}']/ancestor::tr//input[@name='conditionOperatorEnumID']";

    public string ResultListItem(int position) => $"{BaseXpath}//div[@class='silkListGridBody']//table[@width>100]//tr[@aria-posinset='{position}']";

    public string SearchResultsButton(string buttonName) => $"{BaseXpath}//td[@class='iconButton']//span[text()='{buttonName}']";

    public string CheckBox(string label) => $"{BaseXpath}//span[text()='{label}']";
}