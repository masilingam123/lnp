using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Utils;

namespace MilesBelgiumRIA.Pages.EnvironmentPage;

public partial class EnvironmentPage : BasePage
{
    private readonly Common common;
    private readonly DateUtils dateUtils;
    private readonly FileUtils fileUtils;
    private readonly RandomUtils randomUtils;
    private readonly IPage _page;

    public EnvironmentPage(Context context, Common common, DateUtils dateUtils, FileUtils fileUtils, RandomUtils randomUtils) : base(context)
    {
        this.common = common;
        this.dateUtils = dateUtils;
        this.fileUtils = fileUtils;
        this.randomUtils = randomUtils;
        _page = context.Page;
    }

    public async Task<string> ReadEnvironmentDetails()
    {
        return await GetText(EnvDetails);
    }

    public string TrimEntries(string version)
    {
        return version.Trim();
    }

    public async Task<string> ReadVersion()
    {
        var content = await ReadEnvironmentDetails();
        var contentArray = content.Split("\n");

        for (int i = 0; i < contentArray.Length - 1; i++)
        {
            if (contentArray[i].Contains("Branch") == true)
            {
                var version = contentArray[i].Split(" ")[2];
                return version;
            }
        }

        return "Version not found";
    }

    public async Task<bool> ValidateResult()
    {
        string actualResult = await GetActualResult();
        string expectedResult = "2wk/release_master_20230814_2wk";
        bool isMatch = string.Equals(actualResult, expectedResult, StringComparison.OrdinalIgnoreCase);
        return isMatch;
    }

    public async Task<string> GetActualResult()
    {
        var actualResult = await ReadEnvironmentDetails();
        return actualResult;
    }
}