namespace MilesBelgiumRIA.Pages.EnvironmentPage;

public partial class EnvironmentPage
{
    public const string EnvDetails = "//td[@class='environmentDiagnostics']";
}