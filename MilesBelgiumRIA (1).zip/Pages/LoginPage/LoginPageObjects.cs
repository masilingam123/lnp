namespace MilesBelgiumRIA.Pages.LoginPage;

public partial class LoginPage
{
    public string InputTextBox(string name) => $"//input[@name='{name}']";
}