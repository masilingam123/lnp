using System;
using System.Threading.Tasks;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;

namespace MilesBelgiumRIA.Pages.LoginPage;

public partial class LoginPage : BasePage
{
    public LoginPage(Context context) : base(context)
    {
    }

    public async Task SubmitCredentials(string username, string password)
    {
        await EnterText(InputTextBox("username"), Environment.GetEnvironmentVariable(username));
        await EnterText(InputTextBox("password"), Environment.GetEnvironmentVariable(password));
        await SendKeys("Enter");
    }
}