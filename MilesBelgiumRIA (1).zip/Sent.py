import os
import win32com.client
import xml.etree.ElementTree as ET
from datetime import datetime as dt
 
 
xml_file_path = os.path.abspath('./TestResults/MilesBelgiumRIA.xml')
 
def extract_test_run_summary(xml_file_path):
    # Parse the XML file
    tree = ET.parse(xml_file_path)
    root = tree.getroot()
 
    # Extract information from the test-run element
    test_run_element = root[2]  
 
    # Convert timestamps to formatted strings
    start_time = dt.fromisoformat(test_run_element.get('start-time')[:-1]).strftime('%Y-%m-%dT%H:%M:%S')
    end_time = dt.fromisoformat(test_run_element.get('end-time')[:-1]).strftime('%Y-%m-%dT%H:%M:%S')
    duration = "{:.2f}".format(float(test_run_element.get('duration')))
 
    summary_dict = {
        "result": test_run_element.get('result'),
        "total_tests": test_run_element.get('total'),
        "passed_tests": test_run_element.get('passed'),
        "failed_tests": test_run_element.get('failed'),
        "warnings": test_run_element.get('warnings'),
        "inconclusive_tests": test_run_element.get('inconclusive'),
        "skipped_tests": test_run_element.get('skipped'),
        "asserts": test_run_element.get('asserts'),
        "start_time": start_time,
        "end_time": end_time,
        "duration": duration
    }
 
    return summary_dict
 
# extract data from XML
summary_dict = extract_test_run_summary(xml_file_path)
 
# Generate HTML-formatted email content
email_content = f"""
<html>
  <body>
    <p style="font-size:14px;">Hello everyone,</p><br>
    <p style="margin-top:14px;">Today's test result was:</p><br>
    <p style="margin-bottom:14px;"><strong>Status: {summary_dict["result"]}.</strong></p>
    <p style="margin-bottom:14px;">Total Tests: {summary_dict["total_tests"]}.</p>
    <p style="margin-bottom:14px;">Passed Tests: {summary_dict["passed_tests"]}.</p>
    <p style="margin-bottom:14px;">Failed Tests: {summary_dict["failed_tests"]}.</p>
    <p style="margin-bottom:14px;">Skipped Tests: {summary_dict["skipped_tests"]}.</p>
    <p style="margin-bottom:14px;">Start Time: {summary_dict["start_time"]}.</p>
    <p style="margin-bottom:14px;">End Time: {summary_dict["end_time"]}.</p>
    <p style="margin-bottom:14px;">Duration: {summary_dict["duration"]} seconds.</p><br><br>
    <p style="margin-bottom:14px;">For more details, please find attached the reports.</p>
   
   
     
 
    <p style="font-size:14px;">Best Regards,</p>
    <p style="font-size:14px;">Monica Melo</p>
  </body>
</html>
"""
 
# Send the email with the log file as an attachment using Outlook
outlook = win32com.client.Dispatch('Outlook.Application')
namespace = outlook.GetNamespace("MAPI")
 
receiver_emails =  'monica.melo@vwfs.com'
cc_email = 'monica.melo@vwfs.com'
 
mail = outlook.CreateItem(0)
mail.Subject = f'MilesBelgiumRIA - Test Results '
 
# Set the HTML body
mail.HTMLBody = email_content
 
# Attach log file using the absolute path
mail.Attachments.Add(Source=xml_file_path)
 
# Add the recipient
mail.To = receiver_emails
mail.CC = cc_email
 
# Send the email
mail.Send()
print("Email sent successfully.")