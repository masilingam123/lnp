import os
import requests
import xml.etree.ElementTree as ET
 
def get_setting_value(setting_name):
    settings_file_path = os.path.abspath('test.runsettings')
 
    tree = ET.parse(settings_file_path)
    root = tree.getroot()
 
    setting_value = root.find(f".//{setting_name}").text
 
    print(f"{setting_name}: {setting_value}")
    return setting_value
 
 
def import_test_execution():
    api_url = "https://jira.platform.vwfs.io/rest/raven/1.0/import/execution/nunit"
 
    bearer_token = get_setting_value("BEARER")
    project = get_setting_value("PROJECT")
    test_exec = get_setting_value("TEST_EXECUTION")
 
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "X-Atlassian-Token": "no-check"
    }
 
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, "TestResults", "MilesBelgiumRIA.xml")
 
    with open(file_path, 'rb') as file:
        files = {'file': ('MilesBelgiumRIA.xml', file)}
        params = {"projectKey": project, "testExecKey": test_exec}
 
        response = requests.post(api_url, headers=headers, params=params, files=files)
 
    response.raise_for_status()
 
def attach_html_file_to_jira_ticket():
   
    test_exec = get_setting_value("TEST_EXECUTION")
    bearer_token = get_setting_value("BEARER")
 
    api_url = f"https://jira.platform.vwfs.io/rest/api/2/issue/{test_exec}/attachments"
 
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "X-Atlassian-Token": "no-check"
    }
 
    current_directory = os.getcwd()
    file_path = os.path.join(current_directory, "Reports", "complete.html")
 
    with open(file_path, 'rb') as file:
        files = {'file': ('complete.html', file)}
        response = requests.post(api_url, headers=headers, files=files)
 
    response.raise_for_status()
 
if __name__ == "__main__":
    os.environ['HTTPS_PROXY'] = "http://zscaler-prod.fs01.vwf.vwfs-ad:8080"
    import_test_execution()
    attach_html_file_to_jira_ticket()