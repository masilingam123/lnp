# Introduction 

# Features
* Test description in Gherkin
* Interactions with the User Interface
* Execution Reports
* Parallelization
* Multi-browser support
* Test-Filter
* Import Data from json files
* Actions at the level of Rest-Api
* Reporting to Jira

# Technologies
* Specflow
    * Specflow is a testing framework supporting BDD practices in.NET framework.
    * Specflow is used to bind feature files written in Gherkin to C# code that can be run by a test runner.
* Playwright
    * PlaywrightSharp is a .Net library to automate Chromium, Firefox and WebKit browsers.
* Xpath
    * XPath is used to locate elements and attributes in an HTML document.
* Nunit
* Allure-Report
    * Allure Framework is a flexible lightweight multi-language test report tool that not only shows a very concise representation of what have been tested in a neat web report form, but allows everyone participating in the development process to extract maximum of useful information from everyday execution of tests.

# Languages
C# - DotNet 6.0

# Design Pattern
### Page Object Model
It is a design pattern for enhancing test maintenance and reducing code duplication.
A page object is an object-oriented class that serves as an interface to a page of your AUT.
It creates separate class file for each page of the application to group all the elements as properties and their behaviors / business functionalities as methods of the class.
It satisfies the Single Responsibility.

# Repository Folder Structure
This repository has the following folder Structure
* Data - Storage of the data that the framework uses for its execution
* Drivers - Initialization of the drivers for a browser
* Features - Files that contain Gherkin sentences describing the tests
* Hooks - Hooks (event bindings) are used to perform additional automation logic at specific times, such as any setup required prior to executing a scenario. 
* Pages (each page is represented by a directory with the following classes)
    * Objects - The objects are represented by its xpath location
    * Validations - The asserts are executed here in order to validate the expectations of the test
    * Actions - The actions that are executed in the User Interface
* Steps - The Gherkin sentences are coded here. It provides the connection between your feature files and application interfaces.
* TestData - Files that contain data for the usage of the framework e.g. json files
* Utils - Helper classes. This classes are separated from the business layer.
* projectName.cproj - The dependencies are stated here
* test.runsettings - The specifications for the tests are stated here like which tests will run or the environments variables

# Getting Started
0. Preconditions
    * Dotnet installed (actually 6.0)
1.	Installation process
    * Install Playwright browsers
        * $env:HTTPS_PROXY="http://zscaler-prod.fs01.vwf.vwfs-ad:8080" (dev vdis)
        * pwsh bin\Debug\net6.0\playwright.ps1 install (where X is the version of the dotnet installed) 
    * Clean and build solution
        * run "dotnet clean" and "dotnet build"

# Execute
run "dotnet test -s .\test.runsettings"