namespace MilesBelgiumRIA.Resources.Enums;
public enum QuickBarSelect
{
    Search,
    New,
    Direct
}