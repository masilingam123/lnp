namespace MilesBelgiumRIA.Resources.Enums;
public enum MessageGridType
{
    Confirmation,
    Warning
}