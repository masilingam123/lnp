namespace MilesBelgiumRIA.Resources.Models;

public class NewPortalMenu
{
    public string Menu { get; set; }
    public string PageTitle { get; set; }
}