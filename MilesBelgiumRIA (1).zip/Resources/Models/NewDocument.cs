namespace MilesBelgiumRIA.Resources.Models;

public class NewDocument
{
    public string DocumentTemplate { get; set; }
    public string Strategy { get; set; }
}