namespace MilesBelgiumRIA.Resources.Models;

public class CUQuote
{
    public string QuotationTemplate { get; set; }
    public string Driver { get; set; }
    public string Make { get; set; }
    public string Model { get; set; }
    public string Type { get; set; }
    public string NewStock { get; set; }
    public string Duration { get; set; }
    public string Distance { get; set; }
}