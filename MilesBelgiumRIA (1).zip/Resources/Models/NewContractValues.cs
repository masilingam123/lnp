namespace MilesBelgiumRIA.Resources.Models;

public class NewContractValues
{
    public string TotalDuration { get; set; }
    public string TotalDistance { get; set; }
}