using System;
using System.Globalization;

namespace MilesBelgiumRIA.Utils;

public class DateUtils
{
    public DateTime ConvertToDateTime(string inputDate, string inputFormat = "dd/MM/yyyy HH:mm")
    {
        CultureInfo provider = CultureInfo.InvariantCulture;
        var date = DateTime.ParseExact(inputDate, inputFormat, provider);
        return date;
    }

    public TimeSpan SubtractDate(DateTime date1, DateTime date2)
    {
        return date1.Subtract(date2);
    }

    public int GetBusinessDays(DateTime startDate, DateTime endDate)
    {
        int days = 0;
        while (startDate <= endDate)
        {
            if (startDate.DayOfWeek != DayOfWeek.Saturday && startDate.DayOfWeek != DayOfWeek.Sunday)
            {
                ++days;
            }

            startDate = startDate.AddDays(1);
        }

        return days;
    }
}