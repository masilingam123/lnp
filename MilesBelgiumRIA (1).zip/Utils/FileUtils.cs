using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Hooks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.ObjectPage;

namespace MilesBelgiumRIA.Utils;

public class FileUtils : BasePage
{
    private readonly RandomUtils randomUtils;

    public FileUtils(Context context, RandomUtils randomUtils) : base(context)
    {
        this.randomUtils = randomUtils;
    }

    public async Task<string> WaitForDownloadAndSaveFile(string buttonSelector, string downloadfileType)
    {
        var download = await ClickAndWaitForDownload(buttonSelector);
        var path = await download.PathAsync();
        var rndFileName = randomUtils.GenerateRandomString(10);
        var filePath = Environment.ExpandEnvironmentVariables(Environment.GetEnvironmentVariable("DOWNLOAD_PATH") + rndFileName + downloadfileType);
        await download.SaveAsAsync(filePath);
        return filePath;
    }

    public async Task<string> ExtractAndReadFile(string sourceArchiveFile, string destinationDirectory, string fileToRead)
    {
        ZipFile.ExtractToDirectory(sourceArchiveFile, destinationDirectory, true);
        return await File.ReadAllTextAsync(destinationDirectory + "/" + fileToRead);
    }

    public void WriteToCSV(string data, string filePath)
    {
        using (StreamWriter sw = File.AppendText(filePath))
        {
            sw.WriteLine(data);
            sw.Close();
        }
    }
}