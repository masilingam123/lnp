using System;
using System.Linq;

namespace MilesBelgiumRIA.Utils;

public class RandomUtils
{
    private Random rnd = new Random();

    public int GenerateRandomNumber(int minValue, int maxValue)
    {
        return rnd.Next(minValue, maxValue);
    }

    public string GenerateRandomString(int size)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return new string(Enumerable.Repeat(chars, size)
            .Select(s => s[rnd.Next(s.Length)]).ToArray());
    }

    public string GenerateRandomNumber(int size)
    {
        const string chars = "0123456789";
        return new string(Enumerable.Repeat(chars, size)
            .Select(s => s[rnd.Next(s.Length)]).ToArray());
    }
}