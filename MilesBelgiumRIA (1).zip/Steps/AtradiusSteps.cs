using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class AtradiusSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;

    public AtradiusSteps(ScenarioContext scenarioContext, ObjectPage objectPage, SearchPage searchPage)
    {
        this.scenarioContext = scenarioContext;
        this.objectPage = objectPage;
        this.searchPage = searchPage;
    }

    [When(@"the user submits the credit application using Atradius")]
    public async Task WhenTheUserSubmitsTheCreditApplicationUsingAtradius()
    {
        await objectPage.ClickSideMenu(1, "Atradius Credit Scores");
        await searchPage.ClickSearchResulstButton("Open");
        await objectPage.ClickRibbonBarButton("Submit For Scoring");
    }

    [Then(@"the credit application status is '(.*)'")]
    public async Task ThenTheCreditApplicationStatusIs(string expectedStatus)
    {
        await objectPage.CheckFieldContent("Status", expectedStatus, 90000);
        await objectPage.CheckInputFieldNotEmpty("Atradius Ref");
        await objectPage.CheckTextAreaFieldNotEmpty("Masterscale");
        await objectPage.CheckInputFieldNotEmpty("Graydon risk");
    }
}