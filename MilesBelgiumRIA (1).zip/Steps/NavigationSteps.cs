using System;
using System.IO;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Resources.Enums;
using MilesBelgiumRIA.Utils;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class NavigationSteps
{
    private readonly MainToolbar mainToolBar;
    private readonly ScenarioContext scenarioContext;
    private readonly SearchPage searchPage;
    private readonly BasePage basePage;
    private readonly FileUtils fileUtils;

    public NavigationSteps(MainToolbar mainToolBar, SearchPage searchPage, ScenarioContext scenarioContext, BasePage basePage, FileUtils fileUtils)
    {
        this.mainToolBar = mainToolBar;
        this.searchPage = searchPage;
        this.scenarioContext = scenarioContext;
        this.basePage = basePage;
        this.fileUtils = fileUtils;
    }

    [Given(@"the user searches for customer '(.*)'")]
    public async Task GivenTheUserSearchesForCustomer(string name)
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.Search);
        if (name == "random")
        {
            await searchPage.ClickSearchButton();
            await searchPage.ClickRandomResultItem();
        }
        else if (name == "retail")
        {
            var customerData = File.ReadAllText("../../../Test Data/Customer/Retail.json");
            var retailCustomer = JObject.Parse(customerData)["CU1"].ToString();
            await searchPage.SetInputFieldValue("Trading Name", retailCustomer);
            await searchPage.ClickSearchButton();
            await searchPage.ClickResultItem(1);
        }
    }

    [When(@"the user navigates to new customer")]
    public async Task WhenTheUserNavigatesToNewCustomer()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.New);
    }

    [When(@"the user searches for the created customer")]
    public async Task WhenTheUserSearchesForTheCreatedCustomer()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.Search);
        await searchPage.SetInputField("ID", (string)scenarioContext["cuReference"]);
        await searchPage.ClickResultItem(1);
    }

    [When(@"the user searches for the created supplier")]
    public async Task WhenTheUserSearchesForTheCreatedSupplier()
    {
        await mainToolBar.QuickNavigationSearch("Supplier", QuickBarSelect.Search);
        await searchPage.SetSelectionQuery("Find supplier");
        await searchPage.SetInputField("ID", (string)scenarioContext["suReference"]);
        await searchPage.ClickResultItem(1);
    }

    [Then(@"the user searches for the contract")]
    public async Task ThenTheUserSearchesForTheContract()
    {
        await mainToolBar.QuickNavigationSearch("LTC", QuickBarSelect.Search);
        await searchPage.SetInputField("ID", (string)scenarioContext["ltcReference"]);
        await searchPage.ClickResultItem(1);
    }

    [Given(@"the user searches for the '(.*)' contract")]
    public async Task GivenTheUserSearchesForTheContract(string contractID)
    {
        await mainToolBar.QuickNavigationSearch("ltc", QuickBarSelect.Search);
        await searchPage.SetInputField("ID", contractID);
        await searchPage.ClickResultItem(1);
    }

    [Given(@"the user searches for a contract Running")]
    public async Task GivenTheUserSearchesForAContractRunning()
    {
        DateTime currDay = DateTime.Now;
        var yesterday = currDay.AddDays(-1).ToString("dd-MM-yyyy");
        var today = currDay.AddDays(0).ToString("dd-MM-yyyy");

        await mainToolBar.QuickNavigationSearch("ltc", QuickBarSelect.Search);
        await searchPage.SetInputFieldTab("Customer name", "%road%tired%");
        await searchPage.SetInputFieldNth("Contract status", "Running");
        await searchPage.SetInputConditionSign("Start Date", "<=");
        await searchPage.SetInputField("Start Date", today);
        await searchPage.ClickResultItem(1);
    }
}