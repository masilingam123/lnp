using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.CreateDocumentPage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Resources.Models;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class DocumentCreationSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly ObjectPage objectPage;
    private readonly CreateDocumentPage createDocumentPage;

    public DocumentCreationSteps(ScenarioContext scenarioContext, ObjectPage objectPage, CreateDocumentPage createDocumentPage)
    {
        this.scenarioContext = scenarioContext;
        this.objectPage = objectPage;
        this.createDocumentPage = createDocumentPage;
    }

    [When("the user creates a document with")]
    public async Task WhenTheUserCreatesaDocumentWith(Table newDocument)
    {
        await objectPage.ClickRibbonBarButton("New Document");
        var newDoc = newDocument.CreateInstance<NewDocument>();
        await createDocumentPage.SelectTemplate(newDoc.DocumentTemplate);
        await createDocumentPage.SelectStrategy(newDoc.Strategy);
        await createDocumentPage.ClickNext();
    }

    [When("the user previews the document")]
    public async Task WhenTheUserPreviewsTheDocument()
    {
        scenarioContext["filePath"] = await createDocumentPage.ClickPreview();
    }

    [When("the user downloads the document")]
    public async Task WhenTheUserDownloadsTheDocument()
    {
        scenarioContext["filePath"] = await createDocumentPage.ClickDownload();
    }

    [When(@"the user sends the email to '(.*)'")]
    public async void WhenTheUserSendsTheEmailTo(string emailAddress)
    {
        await createDocumentPage.ClickNext();
        await createDocumentPage.SetEmailRecipient(emailAddress);
        await createDocumentPage.ClickMail();
    }

    [Then("the user verifies that the file exists")]
    public void ThenTheUserVerifiesThatTheFileExists()
    {
        createDocumentPage.CheckDocumentFileExists((string)scenarioContext["filePath"]);
    }

    [Then(@"the message with text '(.*)' appears")]
    public async Task ThenTheMessageWithTextAppears(string expectedMessage)
    {
        await createDocumentPage.CheckSuccessMessage(expectedMessage);
    }
}