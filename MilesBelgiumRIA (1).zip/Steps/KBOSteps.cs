using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class KBOSteps
{
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;

    public KBOSteps(ObjectPage objectPage, SearchPage searchPage)
    {
        this.objectPage = objectPage;
        this.searchPage = searchPage;
    }

    [When(@"the user uses the KBO database")]
    public async Task WhenTheUserUsesTheKBODatabase()
    {
        await objectPage.ClickRibbonBarButton("KBO");
        await searchPage.SetInputFieldValue("TradingName", "%Huys%");
        await searchPage.ClickSearchResulstButton("Search");
        await searchPage.ClickRandomResultItem();
    }

    [Then(@"the user validates that the Vat number is imported")]
    public async Task ThenTheUserValidatesThatTheVatNumberIsImported()
    {
        await objectPage.CheckInputFieldNotEmpty("VAT Number", 20000);
    }
}