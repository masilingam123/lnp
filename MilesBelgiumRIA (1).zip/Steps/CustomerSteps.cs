using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Pages.TabBarPage;
using MilesBelgiumRIA.Resources.Enums;

using NUnit.Framework;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class CustomerSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;
    private readonly BasePage basePage;
    private readonly Common commonPage;
    private readonly TabBarPage tabBarPage;
    // private NewCU customerDetails;

    private readonly Dictionary<string, Dictionary<string, string>> customerData = Common.ReadJsonFileAsDictionary("Customer", "CustomerData");
    private readonly Dictionary<string, Dictionary<string, string>> personData = Common.ReadJsonFileAsDictionary("Person", "PersonData");
    public CustomerSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, ObjectPage objectPage, SearchPage searchPage, TabBarPage tabBarPage, BasePage basePage, Common commonPage)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.objectPage = objectPage;
        this.searchPage = searchPage;
        this.basePage = basePage;
        this.commonPage = commonPage;
        this.tabBarPage = tabBarPage;
    }

    [When(@"the user creates a customer prospect")]
    public async Task WhenTheUserCreatesACustomerProspect()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.New);
        await objectPage.SetInputFieldValue("Trading Name", customerData["Road Tired"]["Trading Name"]);
        await objectPage.SetInputFieldValue("Official Registration", customerData["Road Tired"]["Official Registration"]);
        await objectPage.SetInputFieldValue("VAT Number", customerData["Road Tired"]["VAT Number"]);
        await objectPage.ClickGenericButton("Contact Details");
        await objectPage.SetDropDownInsidePopUp("PrimaryContactDetails", "Language", customerData["Road Tired"]["Language"]);
        await objectPage.ClickAddButton("Address");
        await objectPage.SetDropDownGrid("Primary");
        await objectPage.SetGridAddress(2, customerData["Road Tired"]["Street"]);
        await objectPage.SetGridAddress(5, customerData["Road Tired"]["Postal Code"]);
        Thread.Sleep(2000);
        await objectPage.SetGridAddress(6, customerData["Road Tired"]["City"]);
        await objectPage.ClickAddButton("Phone Numbers");
        await objectPage.SetDropDownGrid("Phone (Main)");
        await objectPage.SetGridPhoneNumber(3, customerData["Road Tired"]["Local Number"]);
        await objectPage.ClickAddButton("Internet Details");
        await objectPage.SetDropDownGrid("E-mail");
        await objectPage.SetGridInternetDetails(2, customerData["Road Tired"]["Address"]);
        await objectPage.ClickGenericButton("OK");
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickGenericButton("Yes");
        var cuStatus = await objectPage.ReadInputValue(objectPage.InputTextBox("Partner Status"));
        scenarioContext["cuStatus"] = cuStatus;
    }

    [When(@"the user creates a customer")]
    public async Task WhenTheUserCreatesACustomer()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.New);
        await objectPage.SetInputFieldValue("Trading Name", customerData["Road Tired"]["Trading Name"]);
        await objectPage.SetInputFieldValue("Official Registration", customerData["Road Tired"]["Official Registration"]);
        await objectPage.SetInputFieldValue("VAT Number", customerData["Road Tired"]["VAT Number"]);
        await objectPage.ClickGenericButton("Contact Details");
        await objectPage.SetDropDownInsidePopUp("PrimaryContactDetails", "Language", customerData["Road Tired"]["Language"]);
        await objectPage.ClickAddButton("Address");
        await objectPage.SetDropDownGrid("Primary");
        await objectPage.SetGridAddress(2, customerData["Road Tired"]["Street"]);
        await objectPage.SetGridAddress(5, customerData["Road Tired"]["Postal Code"]);
        Thread.Sleep(2000);
        await objectPage.SetGridAddress(6, customerData["Road Tired"]["City"]);
        await objectPage.ClickAddButton("Phone Numbers");
        await objectPage.SetDropDownGrid("Phone (Main)");
        await objectPage.SetGridPhoneNumber(3, customerData["Road Tired"]["Local Number"]);
        await objectPage.ClickAddButton("Internet Details");
        await objectPage.SetDropDownGrid("E-mail");
        await objectPage.SetGridInternetDetails(2, customerData["Road Tired"]["Address"]);
        await objectPage.ClickGenericButton("OK");
        await objectPage.SetCustomerRole();
        await objectPage.SetPartnerLabels();
        Thread.Sleep(2000);
        await basePage.WaitForLoadingToBeHidden();
        await objectPage.SetInputFieldValue("Overrule Customer Classification", "VDFIN");
        await objectPage.ClickPopUpCheckBox("Prospect");
        await objectPage.SetInputFieldValue("Partner Status", "Qualified (fleet)");
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickGenericButton("Yes");
        var customerRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Partner Reference"));
        scenarioContext["customerReference"] = customerRef;
        var customerName = await objectPage.ReadInputValue(objectPage.InputTextBox("Trading Name"));
        scenarioContext["customerName"] = customerName;
        var cuStatus = await objectPage.ReadInputValue(objectPage.InputTextBox("Partner Status"));
        scenarioContext["cuStatus"] = cuStatus;
        await objectPage.ClickRibbonBarButton("Create Contact");
        await objectPage.ClickGenericButton("Contact Details");
        await objectPage.ClickContactDetailsButton("Person");
        await objectPage.SetInputFieldKeyContact();
        await objectPage.SetInputFieldValue("First Name", personData["Hermione Granger"]["First Name"]);
        await objectPage.SetInputFieldValue("Last Name", personData["Hermione Granger"]["Last Name"]);
        await objectPage.ClickAddButton("Address");
        await basePage.SendKeys("ArrowDown");
        await basePage.SendKeys("Enter");
        await basePage.SendKeys("Tab");
        await objectPage.SetGridAddress2(2, personData["Hermione Granger"]["Street"]);
        await objectPage.SetGridAddress2(5, personData["Hermione Granger"]["Postal Code"]);
        Thread.Sleep(2000);
        await objectPage.SetGridAddress2(6, personData["Hermione Granger"]["City"]);
        await objectPage.ClickAddButton("Phone Numbers");
        await basePage.SendKeys("ArrowDown");
        await basePage.SendKeys("Enter");
        await basePage.SendKeys("Tab");
        await objectPage.SetGridPhoneNumber2(3, personData["Hermione Granger"]["Local Number"]);
        await objectPage.ClickAddButton("Internet Details");
        await basePage.SendKeys("ArrowDown");
        await basePage.SendKeys("Enter");
        await basePage.SendKeys("Tab");
        await objectPage.SetGridInternetDetails2(2, personData["Hermione Granger"]["Address"]);
        await objectPage.ClickGenericButton("OK");
        await objectPage.SetKeyContactRole();
        await objectPage.ClickRibbonBarButton("Save");
        await tabBarPage.ClickTabBar(" CU " + (string)scenarioContext["customerName"]);
    }

    [When(@"the user creates a customer private person")]
    public async Task WhenTheUserCreatesACustomerPrivatePerson()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.New);
        await objectPage.SetInputFieldValue("Legal Entity", "Private Person");
        await objectPage.SetInputFieldPerson("Title", personData["Albus Dumbledore"]["Title"]);
        await objectPage.SetInputFieldValue("First Name", personData["Albus Dumbledore"]["First Name"]);
        await objectPage.SetInputFieldValue("Last Name", personData["Albus Dumbledore"]["Last Name"]);
        await objectPage.SetInputFieldLanguage("Language", personData["Albus Dumbledore"]["Language"]);
        await objectPage.ClickGridAddress(2);
        await objectPage.SetGridAddress(2, personData["Albus Dumbledore"]["Street"]);
        await objectPage.SetGridAddress(5, personData["Albus Dumbledore"]["Postal Code"]);
        Thread.Sleep(2000);
        await objectPage.SetGridAddress(6, personData["Albus Dumbledore"]["City"]);
        await objectPage.ClickPhoneGridLine();
        await objectPage.SetGridPhoneNumber(3, personData["Albus Dumbledore"]["Local Number"]);
        await basePage.SendKeys("ArrowUp");
        await objectPage.ClickRemoveButton("Phone Numbers");
        await objectPage.ClickAddButton("Internet Details");
        await objectPage.SetDropDownGrid("E-mail");
        await objectPage.SetGridInternetDetails(2, personData["Albus Dumbledore"]["Address"]);
        await basePage.SendKeys("ArrowUp");
        await objectPage.ClickRemoveButton("Internet Details");
        await objectPage.SetCustomerRolePP();
        await objectPage.SetPartnerLabelsPP();
        Thread.Sleep(2000);
        // await basePage.WaitForLoadingToBeHidden();
        // await objectPage.ClickGenericButton("OK");
        await objectPage.SetInputFieldValue("Overrule Customer Classification", "VDFIN");
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickGenericButton("Yes");
        var cuStatus = await objectPage.ReadInputValue(objectPage.InputTextBox("Customer Reference"));
        scenarioContext["cuStatus"] = cuStatus;
    }

    [Then(@"the user validates that the customer is a prospect")]
    public async Task ThenTheUserValidatesThatTheCustomerIsAProspect()
    {
        await objectPage.CheckCustomerProspect();
    }

    [Then(@"the user validates that a quote can be created")]
    public async Task ThenTheUserValidatesThatAQuoteCanBeCreated()
    {
        var createQuote = objectPage.GetElementHandle(objectPage.ObjectRibbonBarButton("Create Quote"));
        await objectPage.CheckCustomerCreation(createQuote);
    }

    [Then(@"the user deletes the created customer")]
    public async Task ThenTheUserDeletesTheCreatedCustomer()
    {
        await objectPage.ClickRibbonBarButton("Delete");
        await objectPage.ClickGenericButton("Yes");
    }
}