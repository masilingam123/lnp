using System;
using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CreateDocumentPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Pages.TabBarPage;
using MilesBelgiumRIA.Resources.Enums;
using MilesBelgiumRIA.Resources.Models;
using MilesBelgiumRIA.Utils;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class ContractModificationSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;
    private readonly CreateDocumentPage createDocumentPage;
    private readonly TabBarPage tabBarPage;
    private readonly RandomUtils randomUtils;
    private readonly BasePage basePage;

    public ContractModificationSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, ObjectPage objectPage, SearchPage searchPage, CreateDocumentPage createDocumentPage, TabBarPage tabBarPage, RandomUtils randomUtils, BasePage basePage)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.objectPage = objectPage;
        this.searchPage = searchPage;
        this.createDocumentPage = createDocumentPage;
        this.tabBarPage = tabBarPage;
        this.randomUtils = randomUtils;
        this.basePage = basePage;
    }

    [When(@"the user modifies a contract")]
    public async Task WhenTheUserModifiesAContract(Table newValues)
    {
        DateTime currDay = DateTime.Now;
        var today = currDay.AddDays(0).ToString("dd-MM-yyyy");

        var contractRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Reference"));
        scenarioContext["contractReference"] = contractRef;
        await objectPage.ClickRibbonBarButton("Modify Contract");
        await objectPage.SetInputFieldValue("Change Reason", "Total distance and duration change");
        await objectPage.SetInputFieldValue_Tab("ContractModification", "Change Date", today);
        await objectPage.ClickPopUpButtonContract("ContractModification", "Next");
        var newVal = newValues.CreateInstance<NewContractValues>();
        await objectPage.SelectTotalDuration(newVal.TotalDuration);
        Thread.Sleep(2000);
        await objectPage.SelectTotalDistance(newVal.TotalDistance);
        await objectPage.ClickPopUpButton("Modify");
        await objectPage.ClickPopUpButton("Modify");
    }

    [When(@"the user approves the contract modified")]
    public async Task WhenTheUserApprovesTheContractModified()
    {
        await objectPage.ClickRibbonBarButton("Validate");
        await objectPage.ClickRibbonBarButton("Approve");
        await tabBarPage.ClickTabBar(" LTC " + (string)scenarioContext["contractReference"]);
        await objectPage.ClickRibbonBarButton("Refresh");
        var ltcRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Reference"));
        scenarioContext["ltcReference"] = ltcRef;
    }

    [Then(@"the user can see the contract modified on the results")]
    public async Task ThenTheUserCanSeeTheContractModifiedOnTheResults()
    {
        await objectPage.CheckFieldContent("Reference", (string)scenarioContext["ltcReference"]);
    }
}