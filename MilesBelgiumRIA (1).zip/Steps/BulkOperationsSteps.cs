using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Resources.Enums;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class BulkOperationsSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly SearchPage searchPage;
    private readonly ObjectPage objectPage;

    public BulkOperationsSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, SearchPage searchPage, ObjectPage objectPage)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.searchPage = searchPage;
        this.objectPage = objectPage;
    }

    [When(@"the user selects the batch job '(.*)'")]
    public async Task WhenTheUserSelectsTheBatchJob(string job)
    {
        await mainToolBar.QuickNavigationSearch("Jobs - Bulk Operations", QuickBarSelect.Search);
        await searchPage.SetInputFieldValue("Name", job);
        await searchPage.ClickSearchButton();
        await searchPage.ClickSearchResulstButton("Open");
    }

    [Then(@"the user validates that the job runs every '(.*)' minutes")]
    public async Task ThenTheUserValidatesThatTheJobRunsEveryMinutes(int minutes)
    {
        await objectPage.CheckHistoryStatusIs("Ended", 5);
        await objectPage.CheckTheJobRunsEvery(minutes, 5);
    }

    [Then(@"the user validates that the job runs every day")]
    public async Task ThenTheUserValidatesThatTheJobRunsEveryDay()
    {
        await objectPage.CheckHistoryStatusIs("Ended", 5);
        await objectPage.CheckTheJobsRunEveryBusinessDay(5);
    }
}