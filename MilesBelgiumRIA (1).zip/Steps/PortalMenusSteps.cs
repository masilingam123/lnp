using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.PortalMenuPage;
using MilesBelgiumRIA.Pages.TabBarPage;
using MilesBelgiumRIA.Resources.Models;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class PortalMenusSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly BasePage basePage;
    private readonly PortalMenuPage portalMenuPage;
    private readonly ObjectPage objectPage;
    private readonly TabBarPage tabBarPage;

    public PortalMenusSteps(ScenarioContext scenarioContext, BasePage basePage, PortalMenuPage portalMenuPage, ObjectPage objectPage, TabBarPage tabBarPage)
    {
        this.scenarioContext = scenarioContext;
        this.basePage = basePage;
        this.portalMenuPage = portalMenuPage;
        this.objectPage = objectPage;
        this.tabBarPage = tabBarPage;
    }

    [Then(@"the user clicks and sees the menu page")]
    public async Task TheUserClicksAndSeesTheMenuPage(Table menuTable)
    {
        var newMenu = menuTable.CreateSet<NewPortalMenu>();

        foreach (var row in newMenu)
        {
            string menuName = row.Menu;
            string menuPageTitle = row.PageTitle;
            await portalMenuPage.SelectMenu(row.Menu);
            var pageTitle = await portalMenuPage.ReadPortalName();
            portalMenuPage.ValidatePortalMenu(menuPageTitle, pageTitle);
            await tabBarPage.ClickTabBar("  Home");
        }
    }

    [Then(@"the user click and see the menu page")]
    public async Task TheUserClickAndSeeTheMenuPage(Table menuTable)
    {
        var newMenu = menuTable.CreateSet<NewPortalMenu>();

        foreach (var row in newMenu)
        {
            string menuName = row.Menu;
            string menuPageTitle = row.PageTitle;
            await portalMenuPage.SelectMenu(row.Menu);
            var pageTitle = await portalMenuPage.ReadPortalName();
            portalMenuPage.ValidatePortalMenu(menuPageTitle, pageTitle);
            await portalMenuPage.ClickHome();
        }
    }
}