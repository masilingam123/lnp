using System;
using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CreateDocumentPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Pages.TabBarPage;
using MilesBelgiumRIA.Utils;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class ContractSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;
    private readonly CreateDocumentPage createDocumentPage;
    private readonly TabBarPage tabBarPage;
    private readonly RandomUtils randomUtils;
    private readonly FileUtils fileUtils;
    private readonly BasePage basePage;

    public ContractSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, ObjectPage objectPage, SearchPage searchPage, CreateDocumentPage createDocumentPage, TabBarPage tabBarPage, RandomUtils randomUtils, FileUtils fileUtils, BasePage basePage)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.objectPage = objectPage;
        this.searchPage = searchPage;
        this.createDocumentPage = createDocumentPage;
        this.tabBarPage = tabBarPage;
        this.randomUtils = randomUtils;
        this.fileUtils = fileUtils;
        this.basePage = basePage;
    }

    [When(@"the user creates a contract")]
    public async Task WhenTheUserCreatesAContract()
    {
        await objectPage.ClickRibbonBarButton("Validate");
        await objectPage.ClickRibbonBarButton("Approve");
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.ClickSideMenu(1, "Resulting Contracts");
        await objectPage.DoubleClickPopUpGrid("Initialized");
        await objectPage.ClickRibbonBarButton("New Document");
        await createDocumentPage.SelectTemplate("Contract Document");
        await createDocumentPage.SelectStrategy("Download");
        await createDocumentPage.ClickNext();
        await createDocumentPage.ClickDownload();
        await createDocumentPage.ClickDocumentCancelButton();
        await objectPage.ClickRibbonBarButton("Refresh");
        var contractRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Reference"));
        scenarioContext["contractReference"] = contractRef;
    }

    [When(@"the user approves the contract")]
    public async Task WhenTheUserApprovesTheContract()
    {
        DateTime currDay = DateTime.Now;
        var dayInFuture = currDay.AddDays(30).ToString("dd/MM/yyyy");
        var yesterday = currDay.AddDays(-1).ToString("dd-MM-yyyy");

        await objectPage.ClickSideMenu(1, "General");
        await objectPage.ClickSideMenu(2, "Documents Follow-Up");
        await objectPage.ClickActivateButton();
        await objectPage.ClickSideMenu(1, "General");
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.ClickRibbonBarButton("Complete");
        await objectPage.ClickPopUpButton("OK");
        await objectPage.SetDropDownValueContract("Contract", "Status", "Validated");
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.ClickRibbonBarButton("Vehicle");
        await objectPage.SetInputFieldValue("ORD Order Status", "Exclude from ORD");
        await objectPage.SetInputFieldValue("Requested Delivery Date", dayInFuture);
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickRibbonBarButton("Approve");
        await objectPage.ClickRibbonBarButton("Confirm");
        await tabBarPage.ClickTabBar(" LTC " + (string)scenarioContext["contractReference"]);
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.ClickRibbonBarButton("Open Vehicle");
        await objectPage.ClickSideMenu(1, "Vehicle Usages");
        await objectPage.ClickSideMenu(2, "Registration and Documents");
        await objectPage.SetInputFieldValue("Chassis Number", randomUtils.GenerateRandomNumber(17));
        await objectPage.ClickAddButton("Registered License Plates");
        await objectPage.SetInputFieldLicensePlate("Registered License Plates", 1, 3);
        await objectPage.SetInputFieldValueGrid("Registered License Plates", 1, 4, yesterday);
        // await objectPage.SetDocuments("Requested"); //"Received");
        await objectPage.ClickRibbonBarButton("Save");
        await tabBarPage.ClickTabBar(" LTC " + (string)scenarioContext["contractReference"]);
        await objectPage.SetDropDownValueContract("Contract", "Status", "Vehicle Pre-delivery");
        await objectPage.ClickRibbonBarButton("Save");
        await objectPage.ClickRibbonBarButton("Deliver");
        Thread.Sleep(2000);
        await objectPage.ClickPopUpButton("OK");
        await objectPage.SetInputFieldValue_Tab("ExpressDelivery", "Date & Time", yesterday);
        await objectPage.SetInputFieldValue_Tab("ExpressDelivery", "Distance", "2");
        await objectPage.ClickPopUpButton("Deliver");
        await objectPage.ClickRibbonBarButton("Refresh");
        var ltcRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Reference"));
        scenarioContext["ltcReference"] = ltcRef;
        fileUtils.WriteToCSV(ltcRef, "../../../TestResults/ltcs.csv");
        var ltcStatus = await objectPage.ReadInputValue(objectPage.InputTextBoxContract("Contract", "Status"));
        scenarioContext["ltcStatus"] = ltcStatus;
    }

    [When(@"the user terminates the contract")]
    public async Task WhenTheUserTerminatesTheContract()
    {
        DateTime currDay = DateTime.Now;
        var yesterday = currDay.AddDays(-1).ToString("dd-MM-yyyy");
        var today = currDay.AddDays(0).ToString("dd-MM-yyyy");

        var ltcRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Reference"));
        scenarioContext["ltcReference"] = ltcRef;
        await objectPage.ClickRibbonBarButton("Propose Termination");
        await objectPage.SetInputFieldValue("Reason", "Early Termination");
        await objectPage.SetInputFieldValue_Tab("ContractTerminationProposal", "Date", today);
        await objectPage.SetInputFieldValue_Tab("ContractTerminationProposal", "Distance", "600");
        await objectPage.ClickPopUpButton("OK");
        await objectPage.DoubleClickGridCell("Quotations", 1, 3);
        await objectPage.ClickRibbonBarButton("Validate");
        await objectPage.ClickRibbonBarButton("Approve");
        await tabBarPage.ClickTabBar(" LTC " + (string)scenarioContext["ltcReference"]);
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.ClickRibbonBarButton("Take In");
        Thread.Sleep(2000);
        await objectPage.ClickPopUpButton("OK");
        await objectPage.SetInputFieldValue_Tab("ExpressTakeIn", "Date & Time", today);
        await objectPage.SetInputFieldValue_Tab("ExpressTakeIn", "Distance", "600");
        await objectPage.ClickPopUpCheckBox("Next");
        await objectPage.SetInputFieldValue("Reason", "Early Termination");
        await objectPage.ClickPopUpCheckBox("Terminate Contract");
        await objectPage.ClickPopUpButton("OK");
    }

    [Then(@"the user validates the contract '(.*)'")]
    public async Task ThenTheUserValidatesTheContract(string status)
    {
        await objectPage.CheckFieldContentContract("Contract", "Status", status);
    }
}