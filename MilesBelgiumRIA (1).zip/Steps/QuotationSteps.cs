using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Resources.Enums;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class QuotationSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly ObjectPage objectPage;
    private readonly MainToolbar mainToolBar;
    private readonly SearchPage searchPage;
    private readonly BasePage basePage;
    private readonly Common commonPage;

    private readonly Dictionary<string, Dictionary<string, string>> carData = Common.ReadJsonFileAsDictionary("Quotes", "CarData");
    public QuotationSteps(ScenarioContext scenarioContext, ObjectPage objectPage, MainToolbar mainToolBar, SearchPage searchPage, BasePage basePage, Common commonPage)
    {
        this.scenarioContext = scenarioContext;
        this.objectPage = objectPage;
        this.mainToolBar = mainToolBar;
        this.searchPage = searchPage;
        this.basePage = basePage;
        this.commonPage = commonPage;
    }

    [Given(@"the user searches for customer")]
    public async Task GivenTheUserSearchesForCustomer()
    {
        await mainToolBar.QuickNavigationSearch("Customer", QuickBarSelect.Search);
        await searchPage.SetInputField("ID", "934129");
        await searchPage.ClickResultItem(1);
    }

    [Given(@"the user creates a quote")]
    public async Task GivenTheUserCreatesAQuote()
    {
        await objectPage.ClickRibbonBarButton("Create Quote");
        await objectPage.SetDropDownValue("Quotation Template", "Operational Lease (B2B)");
        await objectPage.SetInputFieldValue("Driver", "%%");
        await objectPage.SetInputFieldValue("Expiration Date", "31/12/2024");
        await objectPage.SetDropDownValue("Make", "AUDI");
        await objectPage.SetDropDownValue("Model", "A3 SEDAN");
        await objectPage.SetInputFieldValue("Type", "30 TDi S line");
        await objectPage.SetInputFieldValue("Dealer", "Audi Steveny Waterloo");
        Thread.Sleep(3000);
        await objectPage.SetInputFieldValue("DealerContact", "Alba, Carlo");
        Thread.Sleep(3000);
        await objectPage.SetInputFieldValue("New/Stock", "New");
        await objectPage.SetInputFieldValue("Duration", "24");
        await objectPage.SetInputFieldValue("Distance", "50000");
        await objectPage.ClickRibbonBarButton("Calculate");
    }

    [Given(@"the user validates the quote")]
    public async Task GivenTheUserValidatesTheQuote()
    {
        await objectPage.ClickRibbonBarButton("Validate");
    }

    [When(@"the user validates the quote")]
    public async Task WhenTheUserValidatesTheQuote()
    {
        await objectPage.ClickRibbonBarButton("Validate");
    }

    [Given(@"the user approves the quote")]
    public async Task GivenTheUserApprovesTheQuote()
    {
        await objectPage.ClickRibbonBarButton("Approve");
        await objectPage.CheckFieldContent("Status", "Credit/Compliance decision pending");
    }

    [Given(@"the user adds an equipment")]
    public async Task GivenTheUserAddsAnEquipment()
    {
        await objectPage.SendKeysPopUp("F11");
        await objectPage.ClickPopUpButton("Catalog");
        await objectPage.ClickPopUpGrid("Audi Phone Box");
        await objectPage.ClickPopUpButton("Generic");
        await objectPage.ClickPopUpButton("Color");
        await objectPage.ClickPopUpGrid("Orange");
        await objectPage.ClickPopUpButton("Add selected generic options");
        await objectPage.ClickPopUpButton("Upholstery");
        await objectPage.ClickPopUpGrid("Cuir Prem");
        await objectPage.ClickPopUpButton("Add selected generic options");
        await objectPage.ClickPopUpButton("OK");
    }

    [When(@"the user creates a quote '(.*)' for this customer")]
    public async Task WhenTheUserCreatesAQuoteForThisCustomer(string template)
    {
        await objectPage.ClickRibbonBarButton("Create Quote");
        await objectPage.SetDropDownValue("Quotation Template", template);
        await objectPage.SetInputFieldValue("Driver", "%%");
        await objectPage.SetDropDownValue("Make", carData["Cupra"]["Make"]);
        await objectPage.SetDropDownValue("Model", carData["Cupra"]["Model"]);
        await objectPage.SetInputFieldValue("Type", carData["Cupra"]["Type"]);
        await objectPage.SetInputFieldValue("New/Stock", carData["Cupra"]["New/Stock"]);
        await objectPage.SetInputFieldValue("Duration", carData["Cupra"]["Duration"]);
        await objectPage.SetInputFieldValue("Distance", carData["Cupra"]["Distance"]);
        if (template == "Financial Renting (B2B)")
        {
            await objectPage.SetInputFieldValue("Purchase Option %", "16");
        }

        await objectPage.ClickRibbonBarButton("Calculate");
        var quoteRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Request"));
        scenarioContext["quoteReference"] = quoteRef;
    }

    [When(@"the user creates a quote")]
    public async Task WhenTheUserCreatesAQuote()
    {
        await objectPage.ClickRibbonBarButton("Create Quote");
        await objectPage.SetDropDownValue("Quotation Template", "Operational Lease (B2B)");
        await objectPage.SetInputFieldValue("Driver", "%%");
        await objectPage.SetDropDownValue("Make", carData["Cupra"]["Make"]);
        await objectPage.SetDropDownValue("Model", carData["Cupra"]["Model"]);
        await objectPage.SetInputFieldValue("Type", carData["Cupra"]["Type"]);
        await objectPage.SetInputFieldValue("New/Stock", carData["Cupra"]["New/Stock"]);
        await objectPage.SetInputFieldValue("Duration", carData["Cupra"]["Duration"]);
        await objectPage.SetInputFieldValue("Distance", carData["Cupra"]["Distance"]);
        await objectPage.ClickRibbonBarButton("Calculate");
        var quoteStatus = await objectPage.ReadInputValue(objectPage.InputTextBox("Status"));
        scenarioContext["quoteStatus"] = quoteStatus;
    }

    [Then(@"the user validates the quote status as '(.*)'")]
    public async Task ThenTheUserValidatesTheQuoteStatusAs(string status)
    {
        await objectPage.CheckFieldContent("Status", status);
    }

    [Then(@"the user validates the quote status Has Matrix as '(.*)'")]
    public async Task ThenTheUserValidatesTheQuoteStatusHasMatrixAs(string status)
    {
        await objectPage.CheckFieldContent("Has Matrix", status);
    }

    [Then(@"the user cancel the created quote")]
    public async Task ThenTheUserCancelTheCreatedQuote()
    {
        await objectPage.ClickRibbonBarButton("Disapprove");
    }
}