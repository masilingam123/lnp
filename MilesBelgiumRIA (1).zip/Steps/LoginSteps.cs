using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.LoginPage;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class LoginSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly Common common;
    private readonly LoginPage login;
    private readonly MainToolbar mainToolbar;

    public LoginSteps(ScenarioContext scenarioContext, Common common, LoginPage login, MainToolbar mainToolbar)
    {
        this.scenarioContext = scenarioContext;
        this.common = common;
        this.login = login;
        this.mainToolbar = mainToolbar;
    }

    [Given("the user has access to '(.*)' as '(.*)' with password '(.*)'")]
    public async Task GivenTheUserHasAccesstoAsWithPassword(string milesEnv, string user, string pass)
    {
        await common.GotoWebPage(milesEnv);
        await login.SubmitCredentials(user, pass);
        scenarioContext["user"] = user;
    }

    [Then("the user can login and see the username on the top of the application")]
    public async Task ThenTheUserCanLoginAndSeeTheUsernameOnTheTopOfTheApplication()
    {
        await mainToolbar.TheUserNameShoulBeTopOfThePage((string)scenarioContext["user"]);
    }

    [Then("the user can login and see the username on the top of the page")]
    public async Task ThenTheUserCanLoginAndSeeTheUsernameOnTheTopOfThePage()
    {
        await mainToolbar.UserNameShouldBeVisible();
    }

    [Then("the user can login and see the username on the page")]
    public async Task ThenTheUserCanLoginAndSeeTheUsernameOnThePage()
    {
        await mainToolbar.UserNameShouldBeOnThePage();
    }
}