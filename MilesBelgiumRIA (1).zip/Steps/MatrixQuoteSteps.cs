using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class MatrixQuoteSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly ObjectPage objectPage;
    private readonly MainToolbar mainToolBar;
    private readonly SearchPage searchPage;
    private readonly BasePage basePage;

    public MatrixQuoteSteps(ScenarioContext scenarioContext, ObjectPage objectPage, MainToolbar mainToolBar, SearchPage searchPage, BasePage basePage)
    {
        this.scenarioContext = scenarioContext;
        this.objectPage = objectPage;
        this.mainToolBar = mainToolBar;
        this.searchPage = searchPage;
        this.basePage = basePage;
    }

    [When(@"the user creates a matrix quote for this customer")]
    public async Task WhenTheUserCreatesAMatrixQuoteForThisCustomer()
    {
        await objectPage.ClickRibbonBarButton("Create Quote");
        await objectPage.SetDropDownValue("Quotation Template", "Operational Lease (B2B) with Matrix");
        await objectPage.SetInputFieldValue("Driver", "%%");
        await objectPage.SetDropDownValue("Make", "CUPRA");
        await objectPage.SetDropDownValue("Model", "FORMENTOR");
        await objectPage.SetInputFieldValue("Type", "2.5 TSI 4Drive VZ5 DSG");
        await objectPage.SetInputFieldValue("New/Stock", "New");
        await objectPage.SetInputFieldValue("Duration", "36");
        await objectPage.SetInputFieldValue("Distance", "120000");
        await objectPage.ClickRibbonBarButton("Calculate");
        var quoteRef = await objectPage.ReadInputValue(objectPage.InputTextBox("Request"));
        scenarioContext["quoteReference"] = quoteRef;
        await objectPage.ClickSideMenu(1, "Lease Service");
        await objectPage.ClickSideMenu(2, "Flex Matrix");
        await objectPage.ClickRibbonBarButton("Calculate Steps");
        await basePage.GetElementByText("Flex Matrix").Nth(3).ClickAsync();
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.WaitForFlexMatrix("Refresh", "Has Matrix");
    }
}