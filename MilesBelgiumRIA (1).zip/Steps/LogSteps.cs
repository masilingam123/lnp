using System;
using System.Threading;
using System.Threading.Tasks;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Resources.Enums;
using MilesBelgiumRIA.Utils;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class LogSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly ObjectPage objectPage;
    private readonly FileUtils fileUtils;

    public LogSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, ObjectPage objectPage, FileUtils fileUtils)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.objectPage = objectPage;
        this.fileUtils = fileUtils;
    }

    [When(@"the user executes the logs")]
    public async Task WhenTheUserExecutesTheLogs()
    {
        await mainToolBar.QuickNavigationSearch("Tools - Log Viewer", QuickBarSelect.Direct);
        await objectPage.ClickRibbonBarButton("Refresh");
        await objectPage.SetInputFieldValue("Extension Of The Error Info Archive", "txt");
        await objectPage.ClickRibbonBarButton("Execute");
        Thread.Sleep(10000);
    }

    [Then(@"the log file is downloaded")]
    public async Task ThenTheLogFileIsDownloaded()
    {
        scenarioContext["filePath"] = await objectPage.ClickLogResultAndWaitForDownload();
    }

    [Then(@"the file contains the date of the execution of logs")]
    public async Task ThenTheFileContainsTheDateOfTheExecutionOfLogs()
    {
        await objectPage.CheckFileContainsDate((string)scenarioContext["filePath"], DateTime.Now);
    }
}