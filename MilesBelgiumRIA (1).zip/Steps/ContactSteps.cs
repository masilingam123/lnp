using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.CommonPage;
using MilesBelgiumRIA.Pages.HomePage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Pages.SearchPage;
using MilesBelgiumRIA.Resources.Enums;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class ContactSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly MainToolbar mainToolBar;
    private readonly ObjectPage objectPage;
    private readonly SearchPage searchPage;
    private readonly BasePage basePage;
    private readonly Common commonPage;

    private readonly Dictionary<string, Dictionary<string, string>> driverData = Common.ReadJsonFileAsDictionary("Driver", "DriverData");
    public ContactSteps(ScenarioContext scenarioContext, MainToolbar mainToolBar, ObjectPage objectPage, SearchPage searchPage, BasePage basePage, Common commonPage)
    {
        this.scenarioContext = scenarioContext;
        this.mainToolBar = mainToolBar;
        this.objectPage = objectPage;
        this.searchPage = searchPage;
        this.basePage = basePage;
        this.commonPage = commonPage;
    }

    [When(@"the user creates a contact")]
    public async Task WhenTheUserCreatesAContact()
    {
        await mainToolBar.QuickNavigationSearch("Driver", QuickBarSelect.New);
        await objectPage.ClickGenericButton("Contact Details");
        Thread.Sleep(2000);
        await objectPage.SetInputInsidePopUp("DriverContactDetails", "Title", driverData["Tim Tim"]["Title"]);
        await objectPage.SetInputInsidePopUp("DriverContactDetails", "First Name", driverData["Tim Tim"]["First Name"]);
        await objectPage.SetInputInsidePopUp("DriverContactDetails", "Last Name", driverData["Tim Tim"]["Last Name"]);
        await objectPage.SetInputInsidePopUp("DriverContactDetails", "Nationality", driverData["Tim Tim"]["Nationality"]);
        await objectPage.ClickAddButton("Address");
        await objectPage.SetDropDownGrid("Primary");
        await objectPage.SetGridAddress(2, driverData["Tim Tim"]["Street"]);
        await objectPage.SetGridAddress(5, driverData["Tim Tim"]["Postal Code"]);
        Thread.Sleep(2000);
        await objectPage.SetGridAddress(6, driverData["Tim Tim"]["City"]);
        await objectPage.ClickAddButton("Phone Numbers");
        await objectPage.SetDropDownGrid("Phone (Main)");
        await objectPage.SetGridPhoneNumber(3, driverData["Tim Tim"]["Local Number"]);
        await objectPage.ClickAddButton("Internet Details");
        await objectPage.SetDropDownGrid("E-mail");
        await objectPage.SetGridInternetDetails(2, driverData["Tim Tim"]["Address"]);
        await objectPage.ClickGenericButton("OK");
        await objectPage.SetLanguage();
        await objectPage.SetInputFieldValue("Business Unit", "Road Tired");
        await objectPage.SetInputFieldValue("Birth Date", "06/06/1996");
        await objectPage.ClickRibbonBarButton("Save");
        Thread.Sleep(2000);
        await objectPage.ClickGenericButton("Yes");
    }

    [Then(@"the user deletes the created contact")]
    public async Task ThenTheUserDeletesTheCreatedContact()
    {
        await objectPage.ClickRibbonBarButton("Delete");
        await objectPage.ClickGenericButton("Yes");
    }
}