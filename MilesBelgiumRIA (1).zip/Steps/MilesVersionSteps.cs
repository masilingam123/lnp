using System.Threading.Tasks;
using Microsoft.Playwright;
using MilesBelgiumRIA.Pages.BasePages;
using MilesBelgiumRIA.Pages.EnvironmentPage;
using MilesBelgiumRIA.Pages.ObjectPage;
using MilesBelgiumRIA.Resources.Enums;
using TechTalk.SpecFlow;

namespace MilesBelgiumRIA.Steps;

[Binding]
public class MilesVersionSteps
{
    private readonly ScenarioContext scenarioContext;
    private readonly ObjectPage objectPage;
    private readonly BasePage basePage;
    private readonly EnvironmentPage environmentPage;

    public MilesVersionSteps(ScenarioContext scenarioContext, ObjectPage objectPage, BasePage basePage, EnvironmentPage environmentPage)
    {
        this.scenarioContext = scenarioContext;
        this.objectPage = objectPage;
        this.basePage = basePage;
        this.environmentPage = environmentPage;
    }

    [When(@"the user opens Environment Details")]
    public async Task WhenTheUserOpensEnvironmentDetails()
    {
        await objectPage.ClickVersionButton();
    }

    [Then(@"the user checks that the version of the application is '(.*)'")]
    public async Task ThenTheUserChecksThatTheVersionOfTheApplicationIs(string version)
    {
        await environmentPage.ReadEnvironmentDetails();
        await environmentPage.ValidateResult();
    }
}