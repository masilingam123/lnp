namespace MilesBelgiumRIA.Models;
public enum BrowserItem
{
    Chromium,
    Firefox,
    WebKit
}