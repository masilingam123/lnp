import subprocess
 
 
# Allure commands
commands = [
    r'allure generate --clean',
    r'allure-combine allure-report',
    r'allure-combine allure-report --dest /Temp',
    r'allure-combine allure-report --dest /Temp/allure-2023-05-29/results --auto-create-folders',
    r'allure-combine allure-report --remove-temp-files',
    r'allure-combine allure-report --ignore-utf8-errors',
]
 
# Run Allure commands
for command in commands:
    subprocess.run(command, shell=True)