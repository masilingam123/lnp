# Versions and changes

## 1.0.8. Added xml files support

## 1.0.7. Added argument --ignore-utf8-errors and make broken utf-8 files be skipped without this argument

## 1.0.6. Fixed bug with wrong sinon.js location

## 1.0.5. New readme file :)

## 1.0.4. Finally made version that successfully installs with pip

## 1.0.0. Initial working version
