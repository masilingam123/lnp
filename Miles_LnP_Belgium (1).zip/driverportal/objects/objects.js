module.exports = class Obj {
    creerofferte = () => "//a[normalize-space()='Creëer offerte']";
    Testlnp = () => "//sof-c-list-item-base-title[normalize-space()='Test LnP']";
    Selecteerbudgetplan = () => "//span[normalize-space()='Selecteer budgetplan']";
    Budgetplan = () => "//span[normalize-space()='Selecteer budgetplan']";
    AudiA1 = () => "//div[contains(text(),'AUDI A1 ALLSTREET 25 TFSI Allst')]";
    Selecteervoertuig = () => "//span[normalize-space()='Selecteer voertuig']";
    Doorgan = () => "//*[contains(text(),' Doorgaan')]";
    Offertes = () => "(//*[contains(text(),' Offertes ')])[1]";    
    }   