// @ts-check
import Contractpageobjects from 'C:/Repos/Miles_LnP_Belgium/driverportal/objects/objects';
const contractpageobjects = new Contractpageobjects();

/**
 * @param {import("playwright-core").Page} page
 */

async function Doorganclick(page){
await page.locator(contractpageobjects.Doorgan()).click();
}
export default { Doorganclick };