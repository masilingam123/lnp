# Introduction 
This repository contains the scenarios and the flows for the BE Load and performance testing
It compreehends 6 scenarios:
* test case 1b - Simple Quote calculation
* test case 1d - Matrix quote calculation
* test case 2b - Quote validation and approval 
* test case 5 - Contract modification
* test case 8 - Web Quote creation as a FM
* test case x - Customer portal (TBD)

# Getting Started
1.	Installation process
    a. Node js installed
    b. npm config set proxy=http://zscaler-prod.fs01.vwf.vwfs-ad:8080
    c. npm install -g artillery
    d. npm install -g artillery artillery-engine-playwright
    e. npm install
    e. npx playwright install

# Run Test
    artillery run .\scenarios\first-scenario.yml -o results.json

# Report results
    artillery report .\results.json
