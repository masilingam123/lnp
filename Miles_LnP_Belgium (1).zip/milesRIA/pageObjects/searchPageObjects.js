module.exports = class Obj {
    BASE_XPATH = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    SearchButton = () => `${this.BASE_XPATH}//td[text()='Search']`;

    SelectionQuery = () => `${this.BASE_XPATH}//input[@name='selection']`;

    SelectionQueryArrowDown = () => `${this.BASE_XPATH}//input[@name='selection']/../..//img`;

    ConditionInputBox = (label) => `${this.BASE_XPATH}//span[text()=' ${label}']/ancestor::tr//input[@name='silk_search_condValue']`;

    ResultListItem = (position) => `${this.BASE_XPATH}//div[@class='silkListGridBody']//table[@width>100]//tr[@aria-posinset='${position}']`;

    SearchResultsButton = (buttonName) => `${this.BASE_XPATH}//td[@class='iconButton']//span[text()='${buttonName}']`;
};
