module.exports = class Obj {
    BASE_XPATH = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    InputTextBox = (name) => `input[name='${name}']`;
    ConditionInputBox = (label) => `${this.BASE_XPATH}//span[text()=' ${label}']/ancestor::tr//input[@name='silk_search_condValue']`;
    search_icon = `${this.BASE_XPATH}//img[@name='isc_DKicon']`
    ObjectRibbonBarButton = (buttonName) => `${this.BASE_XPATH}//div[@role='button']//table/descendant-or-self::*[text()='${buttonName}']`;
    DropDownSelectItem = (itemName) => `//table[contains(@id,'table')]//tr[@role='listitem']//span[text()='${itemName}']`;
    Next =  "//div[contains(@eventproxy,'ContractModification')]//div[@aria-label='Next']"
    PopUpButton = (label) => `//div[@aria-label='${label}']`
    
}   