module.exports = class Obj {
    QuickNavigation = () => `//input[@id='sofid_id_quicknavigation_field']`;
};
