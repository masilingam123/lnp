module.exports = class Obj {
    BASE_XPATH = "//div[contains(@style,'left: 0px') and contains(@eventproxy,'SilkWorkspaceItemRootPane')]";

    InputTextBox = (label) => `${this.BASE_XPATH}//label[text()='${label}']/ancestor::td//input`;

    InputTextBoxLens = (label) => `${this.BASE_XPATH}//label[text()='${label}']/ancestor::td//input/../..//img`;

    ObjectRibbonBarButton = (buttonName) => `${this.BASE_XPATH}//div[@role='button']//table/descendant-or-self::*[text()='${buttonName}']`;

    DropDownSelectItem = (itemName) => `//table[contains(@id,'table')]//tr[@role='listitem']//span[text()='${itemName}']`;

    PageSideMenu = (level, menu) => `${this.BASE_XPATH}//tr[@role='treeitem' and @aria-level='${level}']//div[text()='${menu}']`
};
