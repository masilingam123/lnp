module.exports = class Obj {
    InputTextBox = (label) => `//input[@name='${label}']`;
};