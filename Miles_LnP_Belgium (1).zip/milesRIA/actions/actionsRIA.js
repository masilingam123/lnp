// @ts-check
const { delay, captureCustomMetric } = require('../../utils/utils');
const LoginObjects = require('../../milesRIA/pageObjects/loginPageObjects');
const MainToolBarObjects = require('../../milesRIA/pageObjects/mainToolBarObjects')
const ObjectPageObjects = require('../../milesRIA/pageObjects/objectPageObjects')
const SearchPageObjects = require('../../milesRIA/pageObjects/searchPageObjects')
const loginObjects = new LoginObjects();
const mainToolBarObjects = new MainToolBarObjects();
const objectPageObjects = new ObjectPageObjects();
const searchPageObjects = new SearchPageObjects();
const loginData = require('../../data/login.json');

/**
 * @param {import("playwright-core").Page} page
 * @param {string} url
 * @param {string} user
 * @param {string} pass
 */
async function SubmitCredentials(page, url, user, pass) {
    await page.goto(url);
    await page.locator(loginObjects.InputTextBox("username")).fill(user);
    await page.locator(loginObjects.InputTextBox("password")).fill(pass);
    await page.keyboard.press('Enter');
}

/**
 * @param {import("playwright-core").Page} page
 * @param {string} make
 * @param {string} model
 * @param {string} type
 */
async function InputMakeModeType(page, make, model, type) {
    await page.locator(objectPageObjects.InputTextBox("Make")).click();
    await page.locator(objectPageObjects.DropDownSelectItem(make)).waitFor({state:"attached"});
    await page.locator(objectPageObjects.DropDownSelectItem(make)).click();
    await page.locator(objectPageObjects.InputTextBox("Model")).click();
    await page.locator(objectPageObjects.DropDownSelectItem(model)).click();
    await page.locator(objectPageObjects.InputTextBox("Type")).click();
    await page.locator(objectPageObjects.InputTextBox("Type")).type(type, {delay: 100});
    await page.locator(objectPageObjects.InputTextBox("Type")).press("Enter");
}

/**
 * @param {import("playwright-core").Page} page
 * @param {string} duration
 * @param {string} distance
 * @param {number} sleep
 * @param {number} typeDelay
 */
async function InputDurationDistance(page, duration, distance, sleep, typeDelay){
    await page.locator(objectPageObjects.InputTextBox("Duration")).click();
    await page.locator(objectPageObjects.InputTextBox("Duration")).fill("");
    await page.locator(objectPageObjects.InputTextBox("Duration")).type(duration, {delay: typeDelay});
    await page.locator(objectPageObjects.InputTextBox("Duration")).press("Enter");
    await page.locator(objectPageObjects.InputTextBox("Distance")).click();
    await delay(sleep);
    await page.locator(objectPageObjects.InputTextBox("Distance")).fill("");
    await page.locator(objectPageObjects.InputTextBox("Distance")).type(distance, {delay: typeDelay});
    await page.locator(objectPageObjects.InputTextBox("Distance")).press("Enter");
}

/**
 * @param {import("playwright-core").Page} page
 * @param {string} newStockValue
 */
async function InputNewStock(page, newStockValue ){
    await page.locator(objectPageObjects.InputTextBox("New/Stock")).click();
    await page.locator(objectPageObjects.InputTextBox("New/Stock")).fill(newStockValue);
    await page.locator(objectPageObjects.InputTextBox("New/Stock")).press("Enter");
}

module.exports = { SubmitCredentials, InputMakeModeType, InputDurationDistance, InputNewStock };