module.exports = class Obj {
    Offertesdropdown="//a[@class='dropdown-item sof-p-0.5']//span[contains(text(),'Offertes')]";
    Doorgaan = "//*[contains(text(),' Doorgaan ')]";
    Carpolicymaintence = "//sof-c-list-item-base-title[normalize-space()='Car policy maintenance']";
    Selecteerbestuurder = "//span[normalize-space()='Selecteer bestuurder']";
    Selecteerbudgetplan ="//span[normalize-space()='Selecteer budgetplan']";
    Gadoorzonderbestuurder="//span[normalize-space()='Ga door zonder bestuurder']";
    Goedkeuren="//button[normalize-space()='Goedkeuren']";
    Selecteervoertuig="//span[normalize-space()='Selecteer voertuig']";
    Creeerofferte = "//a[normalize-space()='Creëer offerte']";
    A1ALLSTREET="//div[normalize-space()='A1 ALLSTREET']";
    AUDIA1ALLSTREET25TFSIAllstreet="//div[normalize-space()='AUDI A1 ALLSTREET 25 TFSI Allstreet']";
    Offertegoedkeuren="//h1[normalize-space()='Offerte goedkeuren']";
    Voorstellenaanbestuurder="//button[normalize-space()='Voorstellen aan bestuurder']";
    ja="//span[normalize-space()='Ja']";
    Testlnp = "//sof-c-list-item-base-title[normalize-space()='Test L&P']";
    AudiA1 = "//div[contains(text(),'AUDI A1 ALLSTREET 25 TFSI Allst')]";
    Offertes ="(//*[contains(text(),' Offertes ')])[1]";
    DPAUDIA1ALLSTREET25FSIAllstreet ="//*[contains(text(),'AUDI A1 ALLSTREET 25 TFSI Allstreet')]";
    Openstaande ="//*[contains(text(),'Openstaande')]";
    Quotecheckbox1 ="(//*[contains(text(),'Aan vergelijking toevoe')])[1]";
    Quotecheckbox2="(//*[contains(text(),'Aan vergelijking toevoe')])[2]";
    Vergelijk="//span[normalize-space()='Vergelijk']";
    Toonalleenverschillen ="//label[normalize-space()='Toon alleen verschillen']";
    Geendealergeselecteerd="//*[contains(text(),'Geen dealer geselecteerd')]";
    AutoNatieWilrijk = "//*[contains(text(),'Auto Natie Wilrijk')]";
    Toepassan = "//*[contains(text(),' Toepassen ')]";
    Home = "//a[@class='sof-link'][normalize-space()='Home']";    
    proposedquotesbyFM = "//*[contains(text(),' proposed by your fleet manager. ')]";
    Offertes_Main = "//*[@id='app-root']/sof-root/div/sof-dd-dashboard-view/div/div/div[3]/sof-dd-quotes/div/sof-dd-quote-list[1]/sof-simple-list/sof-dd-quote-list-item[1]";
    FMproposedQuote="(//div[@class='card-body ng-star-inserted'])[1]"
}