// @ts-check

/**
 * @param {import("playwright-core").Page} page
 * @param {string} url
 * @param {string} user
 * @param {string} pass
 */
//Login in Fleetmanager
async function SubmitCredentials(page, url, user, pass) {

    await page.goto(url);
    await page.getByPlaceholder('Username').fill(user);
    await page.getByPlaceholder('Username').press('Tab');
    await page.getByPlaceholder('************').fill(pass);
    await page.keyboard.press('Enter');
}
// Choosing Equipments
async function Equipments(page){
    await page.getByRole('textbox').nth(1).click();
    await page.getByRole('textbox').nth(1).fill('z7');
    await page.getByRole('textbox').nth(1).press('Enter');
}
async function popup(page){
    await page.getByText('Add \'Metaalkleur\'').click();
    await page.getByRole('button', { name: 'Toepassen' }).click();
}
async function Extraequipments(page){
    await page.getByRole('textbox').nth(2).click();
    await page.getByRole('textbox').nth(2).fill('ym');
    await page.getByRole('textbox').nth(2).press('ArrowDown');
    await page.getByRole('textbox').nth(2).press('Enter');
}
// Choosing Duration and Annual mileage
async function Durationandmileage(page){

    await page.getByText('48 maanden').click();
    await page.locator('#cdk-overlay-1').getByText('48 maanden').click();
    await page.getByText('25.000 km').click();
    await page.locator('#cdk-overlay-2').getByText('25.000 km').click();
}



module.exports = { SubmitCredentials , Equipments, Durationandmileage,popup,Extraequipments };