// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const LoginObjects = require('../milesRIA/pageObjects/loginPageObjects');
const MainToolBarObjects = require('../milesRIA/pageObjects/mainToolBarObjects')
const ObjectPageObjects = require('../milesRIA/pageObjects/objectPageObjects')
const SearchPageObjects = require('../milesRIA/pageObjects/searchPageObjects')
const loginObjects = new LoginObjects();
const mainToolBarObjects = new MainToolBarObjects();
const objectPageObjects = new ObjectPageObjects();
const searchPageObjects = new SearchPageObjects();
const loginData = require('../data/login.json');
const quoteData = require('../data/newQuote.json');
const scenarioData = require('../data/scenario2b.json');
const { SubmitCredentials, InputMakeModeType, InputDurationDistance, InputNewStock } = require('../milesRIA/actions/actionsRIA');
const STATIC_DELAY = 38;
const TIMEOUT = 120000;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function quoteValidationApproval(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-ria-staff'].url, loginData['be-ria-staff'].username, loginData['be-ria-staff'].password);
        let timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).waitFor({ state: 'attached' });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Customer search
        timeStartMetric = Date.now();
        const quickNavSearch = "Customer";
        await page.locator(mainToolBarObjects.QuickNavigation()).click();
        await page.locator(mainToolBarObjects.QuickNavigation()).type(quickNavSearch, {delay: 100});
        await page.getByRole('cell', { name: 'Select' }).click();
        await delay(2);
        await page.getByRole('cell', { name: 'Search' }).click();
        await page.locator(searchPageObjects.ConditionInputBox("Trading Name")).fill(userContext.vars.customer.toString());
        await page.locator(searchPageObjects.SearchButton()).click();
        await page.locator(searchPageObjects.ResultListItem(1)).dblclick();
        const metricTime_2_1 = Date.now() - timeStartMetric - quickNavSearch.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.search_customer", metricTime_2_1, events);
        await delay(STATIC_DELAY);

        // Create quote
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Create Quote")).click();
        timeStartMetric = Date.now();
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).waitFor({ state: 'attached' });
        const metricTime_1_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_screen", metricTime_1_2, events);
        await delay(STATIC_DELAY);
        
        // Quotation Template
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).click();
        await page.locator(objectPageObjects.DropDownSelectItem(quoteData.QuotationTemplate)).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_2_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_template", metricTime_2_2, events);
        await delay(STATIC_DELAY);

        // Make Model Type
        await InputMakeModeType(page, quoteData.Make, quoteData.Model, quoteData.Type);
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_2_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.make_model_type", metricTime_2_3, events);
        await delay(STATIC_DELAY);

        // Stock/new + Duration and Distance
        timeStartMetric = Date.now();
        await InputNewStock(page, quoteData['New/Stock']);
        await InputDurationDistance(page, quoteData.Duration, quoteData.Distance, 2, 100);
        const metricTime_2_8 = Date.now() - timeStartMetric - quoteData.Duration.length*100 - quoteData.Distance.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.duration_distance_new", metricTime_2_8, events);
        await delay(STATIC_DELAY);

        // Calculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_3_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.calculate_quote", metricTime_3_1, events);
        await delay(STATIC_DELAY);

        // Validate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Validate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_4_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.validate_quote", metricTime_4_1, events);
        await delay(STATIC_DELAY);

        // Approve
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Approve")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_4_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.approve_quote", metricTime_4_2, events);
        await delay(STATIC_DELAY);
        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Refresh")).click();
        /*
        // Cancel contract
        await page.locator(objectPageObjects.PageSideMenu(1, "Resulting Contracts")).click();
        await page.getByText("Initialized").dblclick();
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Terminate")).click();
        await page.keyboard.press('ArrowDown');
        await page.keyboard.press('Enter');
        // await page.getByLabel("Reason").waitFor({ state: 'attached' });
        // await page.getByLabel("Reason").click();
        await page.locator("//textarea[@name='_param1']").fill("Very valid reason")
        // await page.getByLabel("Reason").type("Very valid reason", {delay: 100});
        await page.getByLabel("Authorized by").fill("ADMIN");
        await page.keyboard.press('Enter');
        await page.getByText("OK").click();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        */
        await delay(STATIC_DELAY);
    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { quoteValidationApproval };