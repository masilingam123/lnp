// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const loginData = require('../data/login.json');
const scenarioData = require('../data/DriverPortal_CheckAndApproveQuote.json');
const Quotecreationobjects = require('../Fleetmanager/Objects/FMobjects');
const quotecreationobjects = new Quotecreationobjects();
const { SubmitCredentials, Equipments, Durationandmileage, popup, Extraequipments } = require('../Fleetmanager/Actions/actionsFM');
const STATIC_DELAY = 34;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */

async function DriverPortal_CheckAndApproveQuote(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        SubmitCredentials(page, loginData['be-web-driver'].url, userContext.vars.email.toString(), userContext.vars.pass.toString())
        let timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.proposedquotesbyFM).waitFor({ state: 'attached', timeout: 120000 });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);

        for (let i = 0; i < 10; i++) { //3min scenario duraion -> 10 iterations 30min
            const timeStart = Date.now();
            await delay(STATIC_DELAY);

            // Navigating to Quotation page
            await page.locator(quotecreationobjects.proposedquotesbyFM).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.FMproposedQuote).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin1_1 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_screen", metricTimeLogin1_1, events);
            await delay(STATIC_DELAY)
            await page.locator(quotecreationobjects.FMproposedQuote).click();

            // Approval page
            await page.locator(quotecreationobjects.Goedkeuren).click();
            await delay(STATIC_DELAY)

            // Select the Dealer
            await page.locator(quotecreationobjects.Geendealergeselecteerd).click();
            await page.locator(quotecreationobjects.AutoNatieWilrijk).click();
            await page.locator(quotecreationobjects.Toepassan).click();
            await delay(STATIC_DELAY)

            // Approve
            await page.locator(quotecreationobjects.Goedkeuren).click();
            timeStartMetric = Date.now();
            await page.locator('nz-notification div').first().waitFor();
            const metricTimeLogin1_2 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.approve_screen", metricTimeLogin1_2, events);
            await delay(STATIC_DELAY)

            const totalTime = Date.now() - timeStart;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

            // Navigate back to home page
            await page.getByRole('link', { name: 'Home' }).click();

        }


    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { DriverPortal_CheckAndApproveQuote };
