// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const loginData = require('../data/login.json');
const scenarioData = require('../data/FMPortal_CreateQuoteProposeToDriver.json');
const Quotecreationobjects = require('../Fleetmanager/Objects/FMobjects');
const quotecreationobjects = new Quotecreationobjects();
const { SubmitCredentials, Equipments, popup, Extraequipments } = require('../Fleetmanager/Actions/actionsFM');
const STATIC_DELAY = 38;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function CreateQuoteProposeToDriver(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        SubmitCredentials(page, loginData['be-web-fm'].url, userContext.vars.email.toString(), userContext.vars.pass.toString());
        let timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached' });
        await page.locator("//sof-loading").waitFor({ state: "hidden" });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        for (let i = 0; i < 5; i++) {
            // Navigating to Create Quote screen
            await page.locator(quotecreationobjects.Creeerofferte).click();
            timeStartMetric = Date.now();
            await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached', timeout: 120000 });
            await page.locator("//sof-loading").waitFor({ state: "hidden", timeout: 120000 });
            const metricTimeLogin_15_1 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.create_quote_screen", metricTimeLogin_15_1, events);
            await delay(STATIC_DELAY);

            //select the driver
            let driver = userContext.vars.driver.toString()
            await page.getByPlaceholder('Filter of zoek bestuurder').click();
            await page.getByPlaceholder('Filter of zoek bestuurder').type(driver);
            await page.getByPlaceholder('Filter of zoek bestuurder').press('Tab');
            await page.locator("//*[contains(text(),'"+driver+",')]").click();
            await page.locator(quotecreationobjects.Selecteerbestuurder).click();

            //Budget plan
            await page.locator(quotecreationobjects.Carpolicymaintence).click();
            await page.locator(quotecreationobjects.Selecteerbudgetplan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.A1ALLSTREET).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin_15_2 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.budget_plan_screen", metricTimeLogin_15_2, events);
            await delay(STATIC_DELAY);

            // Choosing Vehicle
            await page.locator(quotecreationobjects.A1ALLSTREET).click();
            await page.locator(quotecreationobjects.AUDIA1ALLSTREET25TFSIAllstreet).click();
            await page.locator(quotecreationobjects.Selecteervoertuig).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Doorgaan).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin_15_5 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.vehicle_selection", metricTimeLogin_15_5, events);
            await delay(STATIC_DELAY);

            // Choosing Equipments(Cofigure)
            // Choosing Color
            Equipments(page);
            timeStartMetric = Date.now();
            await page.getByText('Add \'Metaalkleur\'').waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin_15_6 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.color_rule_popup", metricTimeLogin_15_6, events);
            await delay(STATIC_DELAY);

            // Add Metallic Color and recalculate
            //popup(page);
            await page.getByText('Add \'Metaalkleur\'').click();
            await page.getByRole('button', { name: 'Toepassen' }).click();
            timeStartMetric = Date.now();
            //await page.getByRole('textbox').nth(2).waitFor({ state: 'attached' });
            await page.locator("//sof-loading").waitFor({ state: "hidden", timeout: 120000 });
            const metricTimeLogin_15_7 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.recalculate_color", metricTimeLogin_15_7, events);
            await delay(STATIC_DELAY);

            // Choosing Upholstery
            //Extraequipments(page);
            await page.getByRole('textbox').nth(2).click();
            await page.getByRole('textbox').nth(2).fill('ym');
            await page.getByRole('textbox').nth(2).press('ArrowDown');
            await page.getByRole('textbox').nth(2).press('Enter');
            timeStartMetric = Date.now();
            await page.locator("//sof-loading").waitFor({ state: "hidden", timeout: 120000 });
            const metricTimeLogin_15_8 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.recalculate_upholstery", metricTimeLogin_15_8, events);
            await delay(STATIC_DELAY);

            // Finance and Services
            await page.locator(quotecreationobjects.Doorgaan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Doorgaan).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin_15_10 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.finance_services_screen", metricTimeLogin_15_10, events);
            await delay(STATIC_DELAY);


            // Choosing Duration and Annual mileage
            await page.waitForTimeout(300);
            await page.locator(quotecreationobjects.Doorgaan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Doorgaan).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin_15_11 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.resume_screen", metricTimeLogin_15_11, events);
            await delay(STATIC_DELAY);

            // Navigate Resume page
            await page.locator(quotecreationobjects.Doorgaan).click();

            // Navigate to Finance and services > Resume        
            //await page.locator("//a[normalize-space()='Doorgaan']").click();

            // Submit Quote page
            await page.locator(quotecreationobjects.Voorstellenaanbestuurder).click();
            await page.locator(quotecreationobjects.ja).click();
            timeStartMetric = Date.now();
            await page.locator('nz-notification div').first().waitFor();
            const metricTimeLogin_15_9 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.propose_to_driver", metricTimeLogin_15_9, events);
            await delay(STATIC_DELAY);

            // Navigate back to home page
            await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Home' }).click();
        }

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.total_elapsed_time', totalTime, events);

    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { CreateQuoteProposeToDriver };
