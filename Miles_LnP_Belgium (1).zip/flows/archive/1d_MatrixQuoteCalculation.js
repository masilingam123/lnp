// @ts-check
const { delay, captureCustomMetric } = require('../../utils/utils');
const LoginObjects = require('../../milesRIA/pageObjects/loginPageObjects');
const MainToolBarObjects = require('../../milesRIA/pageObjects/mainToolBarObjects')
const ObjectPageObjects = require('../../milesRIA/pageObjects/objectPageObjects')
const SearchPageObjects = require('../../milesRIA/pageObjects/searchPageObjects')
const loginObjects = new LoginObjects();
const mainToolBarObjects = new MainToolBarObjects();
const objectPageObjects = new ObjectPageObjects();
const searchPageObjects = new SearchPageObjects();
const loginData = require('../../data/login.json');
const quoteData = require('../../data/newQuote.json');
const scenarioData = require('../../data/scenario1d.json');
const { SubmitCredentials, InputMakeModeType, InputDurationDistance, InputNewStock } = require('../../milesRIA/actions/actionsRIA');
const STATIC_DELAY = 5;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function matrixQuoteCalculation(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-ria'].url, loginData['be-ria'].username, loginData['be-ria'].password);
        let timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).waitFor({ state: 'attached' });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Customer search
        timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).click();
        const quickNavSearch = "Customer";
        await page.locator(mainToolBarObjects.QuickNavigation()).type(quickNavSearch, {delay: 100});
        await page.getByRole('cell', { name: 'Select' }).click();
        await delay(2);
        await page.getByRole('cell', { name: 'Search' }).click();
        await page.locator(searchPageObjects.ConditionInputBox("Trading Name")).fill(userContext.vars.customer.toString());
        await page.locator(searchPageObjects.SearchButton()).click();
        await page.locator(searchPageObjects.ResultListItem(1)).dblclick();
        const metricTime_2_1 = Date.now() - timeStartMetric - quickNavSearch.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.search_customer", metricTime_2_1, events);
        await delay(STATIC_DELAY);

        // Create quote
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Create Quote")).click();
        timeStartMetric = Date.now();
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).waitFor({ state: 'attached' });
        const metricTime_1_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_screen", metricTime_1_2, events);
        await delay(STATIC_DELAY);

        // Quotation Template
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).click();
        await page.locator(objectPageObjects.DropDownSelectItem(quoteData.QuotationTemplateMatrix)).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_2_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_template", metricTime_2_2, events);
        await delay(STATIC_DELAY);

        // Make Model Type
        await InputMakeModeType(page, quoteData.Make, quoteData.Model, quoteData.Type);
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_2_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.make_model_type", metricTime_2_3, events);
        await delay(STATIC_DELAY);

        // Stock/new + Duration and Distance
        timeStartMetric = Date.now();
        await InputNewStock(page, quoteData['New/Stock']);
        await InputDurationDistance(page, quoteData.Duration, quoteData.Distance, 2, 100);
        const metricTime_2_8 = Date.now() - timeStartMetric - quoteData.Duration.length*100 - quoteData.Distance.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.duration_distance_new", metricTime_2_8, events);
        await delay(STATIC_DELAY);

        // Calculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_3_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.calculate_quote", metricTime_3_1, events);
        await delay(STATIC_DELAY);

        // Calculate flex matrix quote
        await page.locator(objectPageObjects.PageSideMenu(1, "Lease Service")).click();
        await page.locator(objectPageObjects.PageSideMenu(2, "Flex Matrix")).click();
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate Steps")).click();
        await page.getByText('Flex Matrix').nth(3).click();
        timeStartMetric = Date.now();
        // Click refresh and wait for "Has Matrix" to be "Yes" (every 20 sec) - timeout 30min
        for (let i = 0; i < 180; i++) { //60*60/20
            await page.locator(objectPageObjects.ObjectRibbonBarButton("Refresh")).click();
            const text = await page.getByLabel("Has Matrix").inputValue();
            // console.log(text)
            if (text == "Yes") {
                const metricTime_3_1 = Date.now() - timeStartMetric;
                captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.load_flex_matrix", metricTime_3_1, events);
                break
            } else {
                await delay(20)
            }
        }

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);
        
        // Cancel quote
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Disapprove")).click();
    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { matrixQuoteCalculation };