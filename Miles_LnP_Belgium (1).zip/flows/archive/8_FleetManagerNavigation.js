// @ts-check
const { delay, captureCustomMetric } = require('../../utils/utils');
const loginData = require('../../data/login.json');
const scenarioData = require('../../data/scenario8.json');
const STATIC_DELAY = 5;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function fleetManagerNavigation(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await page.goto(loginData['be-web-fm'].url);
        await page.getByPlaceholder('Username').fill(userContext.vars.email.toString());
        await page.getByPlaceholder('Username').press('Tab');
        await page.getByPlaceholder('************').fill(userContext.vars.pass.toString());
        await page.getByPlaceholder('************').press('Enter');
        let timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached' });
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Navigate to quotes > ordered quotations
        await page.getByRole('button', { name: 'Offertes' }).click();
        await page.getByRole('link', { name: 'Bestellingen', exact: true }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        const metricTime_15_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_ordered_quote", metricTime_15_1, events);
        await delay(STATIC_DELAY);

        // Navigate to contracts > fleet
        await page.getByRole('button', { name: 'Contracten' }).click();
        await page.getByRole('link', { name: 'Vloot', exact: true }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        await page.locator("//sof-vdfin-contract-list-item").first().waitFor();
        const metricTime_15_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_contract_screen", metricTime_15_3, events);
        await delay(STATIC_DELAY);
        
        // Open a contract
        await page.locator("//sof-vdfin-contract-list-item").first().click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        await page.getByRole('heading', { name: 'Contract' }).waitFor();
        const metricTime_15_4 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_specific_contract", metricTime_15_4, events);
        await delay(STATIC_DELAY);
        
        // Navigate to the reports > dynamic reports
        await page.getByRole('button', { name: 'Verslagen' }).click();
        await page.getByRole('link', { name: 'Rapporten' }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        const metricTime_15_6 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_report_overview", metricTime_15_6, events);
        await delay(STATIC_DELAY);

        // Preview 'invoicing report'
        await page.locator('sof-c-list-item-base').filter({ hasText: 'Facturatie Overzicht maandelijkse facturatie per contract Preview Exporteer CSV ' }).getByRole('button', { name: 'Preview' }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        await page.locator("//table").waitFor();
        const metricTime_15_7 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_invoice_report", metricTime_15_7, events);
        await delay(STATIC_DELAY);

        // Navigate back to reports
        await page.getByRole('button', { name: 'Verslagen' }).click();
        await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Rapporten' }).click();
        await delay(STATIC_DELAY);
        
        // Preview global fleet overview report 
        await page.locator('sof-c-list-item-base').filter({ hasText: 'Globaal vlootoverzicht Globaal vlootoverzicht Preview Exporteer CSV Excel' }).getByRole('button', { name: 'Preview' }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        await page.locator("//table").waitFor();
        const metricTime_15_8 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_fleet_overview", metricTime_15_8, events);
        await delay(STATIC_DELAY);

        // Navigate to drivers
        await page.getByRole('button', { name: 'Bestuurders' }).click();
        await page.getByRole('link', { name: 'Bestuurders', exact: true }).click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        await page.locator("//sof-dm-driver-list-item").first().waitFor();
        const metricTime_15_9 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_driver_overview", metricTime_15_9, events);
        await delay(STATIC_DELAY);

        // Open a driver
        await page.locator("//sof-dm-driver-list-item").first().click();
        timeStartMetric = Date.now();
        await page.locator("//sof-loading").waitFor({state:"hidden"});
        const metricTime_15_10 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_specific_driver", metricTime_15_10, events);
        await delay(STATIC_DELAY);
        
        // Back to home screen
        await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Home' }).click()
        await delay(STATIC_DELAY);

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);
        
    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { fleetManagerNavigation };