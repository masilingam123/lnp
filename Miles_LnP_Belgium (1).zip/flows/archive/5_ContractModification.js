// @ts-nocheck
const { delay, captureCustomMetric } = require('../../utils/utils');
const MainToolBarObjects = require('../../milesRIA/pageObjects/mainToolBarObjects')
const mainToolBarObjects = new MainToolBarObjects();
const loginData = require('../../data/login.json');
const scenarioData = require('../../data/scenario5.json');
const { SubmitCredentials } = require('../../milesRIA/actions/actionsRIA');
const ContractPageObjects = require('../../milesRIA/pageObjects/contractPageObjects')
const SearchPageObjects = require('../../milesRIA/pageObjects/searchPageObjects')
const contractPageObjects = new ContractPageObjects()
const searchPageObjects = new SearchPageObjects();
const STATIC_DELAY = 5;
const TIMEOUT = 120000;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function contractModification(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-ria'].url, loginData['be-ria'].username, loginData['be-ria'].password);
        let timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).waitFor({ state: 'attached' });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // LTC search: 1 - 1.1
        timeStartMetric = Date.now();
        const quickNavSearch = "LTC";
        await page.locator(mainToolBarObjects.QuickNavigation()).click();
        await page.locator(mainToolBarObjects.QuickNavigation()).type(quickNavSearch, {delay: 100});
        await page.getByRole('cell', { name: 'Select' }).click();
        await delay(2);
        await page.getByRole('cell', { name: 'Search' }).click();
        const metricTime_10_1 = Date.now() - timeStartMetric - quickNavSearch.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.contract_screen", metricTime_10_1, events);
        await delay(STATIC_DELAY);

        // LTC search: 2 - 4 
        timeStartMetric = Date.now();
        const contract = userContext.vars.contract.toString()
        await page.locator(contractPageObjects.ConditionInputBox("ID")).fill(contract) 
        await page.locator(searchPageObjects.SearchButton()).click();
        await page.locator(searchPageObjects.SearchResultsButton("Open")).click();
        const metricTime_10_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.ltc_search", metricTime_10_2, events);
        await delay(STATIC_DELAY);
       
        // Contract modification: 5 - 6
        timeStartMetric = Date.now();
        await page.locator(contractPageObjects.ObjectRibbonBarButton('Modify Contract')).click()
        await page.getByLabel('Change Reason').click();
        await delay(2);
        await page.getByLabel('Change Reason').fill("Total distance and duration change");
        await page.getByLabel('Change Date').click();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_11_1 = Date.now() - timeStartMetric - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.start_contract_modification", metricTime_11_1, events);
        await delay(STATIC_DELAY);

        // Change distance and duration
        await page.locator(contractPageObjects.Next).click()
        timeStartMetric = Date.now();
        await page.locator(contractPageObjects.InputTextBox("A13084")).clear()
        await page.locator(contractPageObjects.InputTextBox("A13084")).fill(scenarioData.duration)
        await page.locator(contractPageObjects.InputTextBox("A13083")).clear()
        await page.locator(contractPageObjects.InputTextBox("A13083")).fill(scenarioData.distance)
        const metricTime_11_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.change_distance_duration", metricTime_11_2, events);
        await delay(STATIC_DELAY);

        timeStartMetric = Date.now();
        await page.locator(contractPageObjects.PopUpButton("Modify")).click({ force: true })
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const exist = await page.locator(contractPageObjects.PopUpButton("Modify")).isVisible({ timeout: TIMEOUT });
        if (exist) {
            await page.locator(contractPageObjects.PopUpButton("Modify")).click({ force: true })
        }
        const metricTime_11_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.load_amend_quote", metricTime_11_3, events);
        await delay(STATIC_DELAY);

        // Calculate, Validate
        await page.locator(contractPageObjects.ObjectRibbonBarButton('Calculate')).click()
        await page.locator(contractPageObjects.ObjectRibbonBarButton('Validate')).click()
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_11_4 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.validate", metricTime_11_4, events);
        await delay(STATIC_DELAY);

        // Approve 
        await page.locator(contractPageObjects.ObjectRibbonBarButton('Approve')).click()
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_11_5 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.approve", metricTime_11_5, events);
        await delay(STATIC_DELAY);

        // Contract
        await page.locator(contractPageObjects.ObjectRibbonBarButton('Contract')).click()
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: TIMEOUT});
        const metricTime_11_6 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.contract", metricTime_11_6, events);
        await delay(STATIC_DELAY);
        
    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { contractModification };