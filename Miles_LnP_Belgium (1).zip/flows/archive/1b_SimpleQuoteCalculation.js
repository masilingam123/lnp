// @ts-check
const { delay, captureCustomMetric } = require('../../utils/utils');
const LoginObjects = require('../../milesRIA/pageObjects/loginPageObjects');
const MainToolBarObjects = require('../../milesRIA/pageObjects/mainToolBarObjects')
const ObjectPageObjects = require('../../milesRIA/pageObjects/objectPageObjects')
const SearchPageObjects = require('../../milesRIA/pageObjects/searchPageObjects')
const mainToolBarObjects = new MainToolBarObjects();
const objectPageObjects = new ObjectPageObjects();
const searchPageObjects = new SearchPageObjects();
const loginData = require('../../data/login.json');
const quoteData = require('../../data/newQuote.json');
const scenarioData = require('../../data/scenario1b.json');
const { SubmitCredentials, InputMakeModeType, InputDurationDistance, InputNewStock } = require('../../milesRIA/actions/actionsRIA');
const STATIC_DELAY = 5;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function simpleQuoteCalculation(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-ria'].url, loginData['be-ria'].username, loginData['be-ria'].password);
        let timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).waitFor({ state: 'attached' });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Navigation to new quote
        timeStartMetric = Date.now();
        const quickNavSearch = "Sales - Quotes";
        await page.locator(mainToolBarObjects.QuickNavigation()).click();
        await page.locator(mainToolBarObjects.QuickNavigation()).type(quickNavSearch, {delay: 100});
        await page.getByRole('cell', { name: 'Select' }).click();
        await delay(2);
        await page.getByRole('cell', { name: 'New' }).click();
        const metricTime_1_1 = Date.now() - timeStartMetric - quickNavSearch.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.selection_quote", metricTime_1_1, events);
        await delay(STATIC_DELAY);
        timeStartMetric = Date.now();
        await page.locator(objectPageObjects.InputTextBox("Customer")).waitFor({ state: 'attached' });
        const metricTime_1_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_screen", metricTime_1_2, events);
        await delay(STATIC_DELAY);

        // Search for a customer
        timeStartMetric = Date.now();
        await page.locator(objectPageObjects.InputTextBox("Customer")).click();
        await page.locator(objectPageObjects.InputTextBoxLens("Customer")).click();
        await page.locator(searchPageObjects.SelectionQuery()).waitFor({ state: 'visible' });
        await delay(1);
        await page.locator(searchPageObjects.SelectionQuery()).click();
        await page.locator(searchPageObjects.SelectionQueryArrowDown()).click();
        await delay(1);
        await page.getByText('Show All').click();
        await delay(1);
        await page.getByText('Find customer (B2B)').click();
        await page.locator(searchPageObjects.ConditionInputBox("Trading Name")).fill(userContext.vars.customer.toString())
        await page.locator(searchPageObjects.SearchButton()).click();
        await page.locator(searchPageObjects.ResultListItem(1)).dblclick();
        const metricTime_2_1 = Date.now() - timeStartMetric - 3000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.search_customer", metricTime_2_1, events);
        await delay(1);
        const exist = await page.getByRole('button', { name: 'New Request' }).isVisible({ timeout: 10000 });
        if (exist) {
            await page.getByRole('button', { name: 'New Request' }).click();
        }
        await delay(STATIC_DELAY);

        // Fill quote details
        // Quotation Template
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).click();
        await page.locator(objectPageObjects.DropDownSelectItem(quoteData.QuotationTemplate)).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_2_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_template", metricTime_2_2, events);

        // Driver
        await page.locator(objectPageObjects.InputTextBox("Driver")).click();
        await page.locator(objectPageObjects.InputTextBox("Driver")).fill(quoteData.Driver)
        await page.locator(objectPageObjects.InputTextBox("Driver")).press("Enter");
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        await delay(STATIC_DELAY);

        // Make Model Type
        await InputMakeModeType(page, quoteData.Make, quoteData.Model, quoteData.Type);
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_2_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.make_model_type", metricTime_2_3, events);
        await delay(STATIC_DELAY);

        // Stock/new + Duration and Distance
        timeStartMetric = Date.now();
        await InputNewStock(page, quoteData['New/Stock']);
        await InputDurationDistance(page, quoteData.Duration, quoteData.Distance, 2, 100);
        const metricTime_2_8 = Date.now() - timeStartMetric - quoteData.Duration.length*100 - quoteData.Distance.length*100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.duration_distance_new", metricTime_2_8, events);
        await delay(STATIC_DELAY);

        // Calculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_3_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.calculate_quote", metricTime_3_1, events);
        await delay(STATIC_DELAY);

        // Add minimal equipment
        timeStartMetric = Date.now();
        await page.keyboard.press("F11");
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        await page.getByText("Pack").first().click();
        await page.getByText('Pack Business', { exact: true }).click();
        await page.getByText("Color", { exact: true }).click();
        await page.getByText('Tango Rood').click();
        await page.getByText("Upholstery").click();
        await page.getByText('Beige/zwart/zwart/staalgrijs').click();
        await page.getByRole('button', {name:'OK'}).click();
        const metricTime_2_5 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.min_equipment", metricTime_2_5, events);
        await delay(STATIC_DELAY);

        // Recalculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_3_1_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.recalculate_quote_equi", metricTime_3_1_1, events);
        await delay(STATIC_DELAY);

        // Add services
        timeStartMetric = Date.now();
        await page.keyboard.press("F12");
        await page.getByRole('treeitem', { name: 'Services' }).getByText('Services').dblclick();
        await page.getByRole('treeitem', { name: 'Other Services' }).getByText('Other Services').dblclick();
        await page.locator("//div[text()='Carwash']/../..//span[2]").click();
        await page.getByRole('button', {name:'OK'}).click();
        const metricTime_2_7 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.add_services", metricTime_2_7, events);
        await delay(STATIC_DELAY);

        // Recalculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden' , timeout: 60000});
        const metricTime_3_1_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.recalculate_quote_serv", metricTime_3_1_2, events);
        await delay(STATIC_DELAY);

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

        // Cancel quote
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Disapprove")).click();
    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { simpleQuoteCalculation };