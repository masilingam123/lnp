// @ts-check
const { delay, captureCustomMetric } = require('../../utils/utils');
const loginData = require('../../data/login.json');
const scenarioData = require('../../data/scenario8b.json');
const Quotecreationobjects = require('../../Fleetmanager/Objects/FMobjects');
const quotecreationobjects = new Quotecreationobjects();
const { SubmitCredentials ,Equipments ,Durationandmileage, popup, Extraequipments} = require('../../Fleetmanager/Actions/actionsFM');
const STATIC_DELAY = 5;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function fleetManagerQuoteCreation(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    page.setDefaultTimeout(60000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        SubmitCredentials(page,loginData['be-web-fm'].url,userContext.vars.email.toString(),userContext.vars.pass.toString());
        let timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached' });
        await page.locator("//sof-loading").waitFor({ state: "hidden" });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Navigating to quotation screen
        await page.locator(quotecreationobjects.Creeerofferte).click();
        await page.locator(quotecreationobjects.Offertesdropdown).click();
        timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Creeerofferte).waitFor();
        const metricTimeLogin14_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.QuoteScreen", metricTimeLogin14_1, events);
        await delay(STATIC_DELAY);

        // Navigating to New quote screen
        await page.locator(quotecreationobjects.Creeerofferte).click();
        timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Defreyne, Peter Bestuurdersgroepen Bedrijf Inetum Realdolmen Belgium' }).waitFor();
        const metricTimeLogin14_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.NewQuoteCreation", metricTimeLogin14_2, events);
        await delay(STATIC_DELAY);

        // Select the driver
        await page.getByRole('button', { name: 'Defreyne, Peter Bestuurdersgroepen Bedrijf Inetum Realdolmen Belgium' }).click();

        // Navigate to Director
        timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Gadoorzonderbestuurder).click();

        // Navigate Director to Budget plan
        await page.locator(quotecreationobjects.Carpolicymaintence).click();
        await page.locator(quotecreationobjects.Selecteerbudgetplan).waitFor();
        const metricTimeLogin_15_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.QuotationTemplate", metricTimeLogin_15_2, events);
        await delay(STATIC_DELAY);

        // Choosing Vehicle
        await page.locator(quotecreationobjects.Selecteerbudgetplan).click();
        await page.locator(quotecreationobjects.A1ALLSTREET).click();
        await page.locator(quotecreationobjects.AUDIA1ALLSTREET25TFSIAllstreet).click();
        

        // Navigating vehicle > Configure
        timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Selecteervoertuig).click();
        await page.locator(quotecreationobjects.Doorgaan).waitFor();
        const metricTimeLogin_15_4 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.configure", metricTimeLogin_15_4, events);
        await delay(STATIC_DELAY);

        // Choosing Equipments
        Equipments(page);
        await page.waitForTimeout(300);
        popup(page);
        Extraequipments(page);
        await page.getByText('Stof Debut').click();
        timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Doorgaan).click();
        await page.locator(quotecreationobjects.Doorgaan).waitFor({state: 'attached' });
        const metricTimeLogin_15_5 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.min_equipment", metricTimeLogin_15_5, events);
        await delay(STATIC_DELAY);

        // Choosing Duration and Annual mileage
        Durationandmileage(page);
        await page.waitForTimeout(300);

        // Navigate to Finance and services
        timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Doorgaan).click();

        // Navigate to Finance and services > Resume        
        await page.locator(quotecreationobjects.Doorgaan).click();

        // Navigating Submit Quote page
        await page.locator(quotecreationobjects.Goedkeuren).click();
        await page.locator(quotecreationobjects.Offertegoedkeuren).waitFor({state: 'attached' });
        const metricTimeLogin_16_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.SubmitQuote", metricTimeLogin_16_3, events);

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { fleetManagerQuoteCreation };