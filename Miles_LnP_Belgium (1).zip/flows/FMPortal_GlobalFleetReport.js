// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const loginData = require('../data/login.json');
const scenarioData = require('../data/fmportalglobalfleetreport.json');
const { SubmitCredentials } = require('../milesRIA/actions/actionsRIA');
const STATIC_DELAY = 27;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function fMPortal_GlobalFleetReport(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-web-fm'].url, userContext.vars.email.toString(), userContext.vars.pass.toString());
        let timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached' });
        await page.locator("//sof-loading").waitFor({ state: "hidden", timeout: 120000 });
        const metricTime_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTime_1, events);
        for (let i = 0; i < 15; i++) { //2min scenario duraion -> 15 iterations 30min
            const timeStart = Date.now();
            await delay(STATIC_DELAY);

            // Navigate to reports
            await page.getByRole('button', { name: 'Verslagen' }).click();
            await page.getByRole('link', { name: 'Rapporten' }).click();
            await delay(STATIC_DELAY);

            // Open Global Fleet Report
            await page.locator('sof-c-list-item-base').filter({ hasText: 'Globaal vlootoverzicht Globaal vlootoverzicht Preview Exporteer CSV Excel' }).getByRole('button', { name: 'Preview' }).click();
            timeStartMetric = Date.now();
            await page.locator("//sof-loading").waitFor({ state: "hidden", timeout: 120000 });
            await page.locator("//table").waitFor();
            const metricTime_2 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_fleet_report", metricTime_2, events);
            await delay(STATIC_DELAY);

            // Export Global Fleet Report
            await page.getByRole('button', { name: 'Exporteer' }).click();
            const downloadPromise = page.waitForEvent('download');
            await page.getByRole('button', { name: 'Excel' }).click();
            timeStartMetric = Date.now();
            const download = await downloadPromise;
            const metricTime_3 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.export_report", metricTime_3, events);
            await delay(STATIC_DELAY);

            const totalTime = Date.now() - timeStart;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

            // Navigate back to home page
            await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Home' }).click();
        }

    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { fMPortal_GlobalFleetReport };