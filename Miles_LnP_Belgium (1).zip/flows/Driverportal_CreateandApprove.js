// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const loginData = require('../data/login.json');
const scenarioData = require('../data/Driverportal_CreateQuoteAndApprove.json');
const Quotecreationobjects = require('../Fleetmanager/Objects/FMobjects');
const quotecreationobjects = new Quotecreationobjects();
const { SubmitCredentials } = require('../Fleetmanager/Actions/actionsFM');
const STATIC_DELAY = 29;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */

async function Driverportal_CreateandApprove(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        SubmitCredentials(page, loginData['be-web-driver'].url, userContext.vars.email.toString(), userContext.vars.pass.toString())
        let timeStartMetric = Date.now();
        await page.locator(quotecreationobjects.Creeerofferte).waitFor({ state: 'attached' });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);

        for (let i = 0; i < 6; i++) { //5min scenario duraion -> 6 iterations 30min
            const timeStart = Date.now();
            await delay(STATIC_DELAY);

            //Navigacting to create Quote screen
            await page.locator(quotecreationobjects.Creeerofferte).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Testlnp).waitFor({ state: 'attached' });
            const metricTimeLogin1_1 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.create_quote_screen", metricTimeLogin1_1, events);
            await delay(STATIC_DELAY);

            //select the bugetplan     
            await page.locator(quotecreationobjects.Testlnp).click();
            await page.locator(quotecreationobjects.Selecteerbudgetplan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.DPAUDIA1ALLSTREET25FSIAllstreet).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin1_2 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.budget_plan_screen", metricTimeLogin1_2, events);
            await delay(STATIC_DELAY);

            //Select the Car
            await page.locator(quotecreationobjects.DPAUDIA1ALLSTREET25FSIAllstreet).click();
            await page.locator(quotecreationobjects.Selecteervoertuig).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Doorgaan).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin1_3 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.vehicle_selection", metricTimeLogin1_3, events);
            await delay(STATIC_DELAY);

            //navigating to equipment page
            await page.locator(quotecreationobjects.Doorgaan).click();
            await delay(STATIC_DELAY);

            // Navigating finance and service page
            await page.locator(quotecreationobjects.Doorgaan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Doorgaan).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin1_4 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.finance_service_screen", metricTimeLogin1_4, events);
            await delay(STATIC_DELAY);

            //Navigating to Resume page
            await page.locator(quotecreationobjects.Doorgaan).click();
            timeStartMetric = Date.now();
            await page.locator(quotecreationobjects.Goedkeuren).waitFor({ state: 'attached', timeout: 120000 });
            const metricTimeLogin1_5 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.resume_screen", metricTimeLogin1_5, events);
            await delay(STATIC_DELAY);

            //approval page
            await page.locator(quotecreationobjects.Goedkeuren).click();
            await page.locator(quotecreationobjects.Geendealergeselecteerd).waitFor({ state: 'attached', timeout: 120000 });
            await delay(STATIC_DELAY);

            //select the Dealer
            await page.locator(quotecreationobjects.Geendealergeselecteerd).click();
            await page.locator(quotecreationobjects.AutoNatieWilrijk).click();
            await page.locator(quotecreationobjects.Toepassan).click();
            await delay(STATIC_DELAY);

            //Approve
            await page.locator(quotecreationobjects.Goedkeuren).click();
            timeStartMetric = Date.now();
            await page.locator('nz-notification div').first().waitFor();
            const metricTimeLogin1_6 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.Approve", metricTimeLogin1_6, events);
            await delay(STATIC_DELAY);

            const totalTime = Date.now() - timeStart;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

            // Navigate back to home page
            await page.getByRole('link', { name: 'Home' }).click();
        }


    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { Driverportal_CreateandApprove };
