// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const loginData = require('../data/login.json');
const scenarioData = require('../data/fmportalopenordersoverview.json');
const { SubmitCredentials } = require('../milesRIA/actions/actionsRIA');
const ObjectPageObjects = require('../milesRIA/pageObjects/objectPageObjects')
const objectPageObjects = new ObjectPageObjects();
const STATIC_DELAY = 17;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function fMPortal_OpenOrdersOverview(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-web-fm'].url, userContext.vars.email.toString(), userContext.vars.pass.toString());
        let timeStartMetric = Date.now();
        await page.getByRole('button', { name: 'Offertes' }).waitFor({ state: 'attached' });
        await page.locator("//sof-loading").waitFor({ state: "hidden" });
        const metricTime_1 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTime_1, events);
        for (let i = 0; i < 30; i++) { //1min scenario duraion -> 30 iterations 30min
            const timeStart = Date.now();
            await delay(STATIC_DELAY);

            // Open Orders Overview 1 way
            await page.locator("//div[text()='Bestellingen']").click();
            timeStartMetric = Date.now();
            await page.locator("//sof-loading").waitFor({ state: "hidden" });
            await page.locator("//span[text()=' Bestelling geplaatst ']").waitFor();
            const metricTime_2 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_overview_1way", metricTime_2, events);
            await page.locator("//span[text()=' Bestelling geplaatst ']").click();
            await delay(STATIC_DELAY);

            // Open Orders Overview 2 way
            await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Home' }).click();
            await page.getByRole('button', { name: 'Offertes' }).click();
            await page.getByRole('link', { name: 'Bestellingen', exact: true }).click();
            timeStartMetric = Date.now();
            await page.locator("//sof-loading").waitFor({ state: "hidden" });
            await page.locator("//span[text()=' Bestelling geplaatst ']").waitFor();
            const metricTime_3 = Date.now() - timeStartMetric;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.open_overview_2way", metricTime_3, events);
            await page.locator("//span[text()=' Bestelling geplaatst ']").click();
            await delay(STATIC_DELAY);

            const totalTime = Date.now() - timeStart;
            captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

            // Navigate back to home page
            await page.locator('sof-top-bar-nav').getByRole('link', { name: 'Home' }).click();
        }

    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { fMPortal_OpenOrdersOverview };