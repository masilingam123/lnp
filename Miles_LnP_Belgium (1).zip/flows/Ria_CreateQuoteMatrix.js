// @ts-check
const { delay, captureCustomMetric } = require('../utils/utils');
const MainToolBarObjects = require('../milesRIA/pageObjects/mainToolBarObjects')
const ObjectPageObjects = require('../milesRIA/pageObjects/objectPageObjects')
const SearchPageObjects = require('../milesRIA/pageObjects/searchPageObjects')
const mainToolBarObjects = new MainToolBarObjects();
const objectPageObjects = new ObjectPageObjects();
const searchPageObjects = new SearchPageObjects();
const loginData = require('../data/login.json');
const scenarioData = require('../data/RiaCreateQuoteMatrix.json');
const { SubmitCredentials, InputMakeModeType, InputDurationDistance, InputNewStock } = require('../milesRIA/actions/actionsRIA');
const STATIC_DELAY = 27;

/**
 * @param {import("playwright-core").Page} page
 * @param {any} userContext
 * @param {any} events
 */
async function riaquotecreatematrix(page, userContext, events) {
    const workerUUID = userContext.vars['$uuid'];
    const timeStart = Date.now();
    const browser = page.context();
    page.setDefaultTimeout(200000);
    await browser.tracing.start({ screenshots: true, snapshots: true });

    try {
        // Login
        await SubmitCredentials(page, loginData['be-ria'].url, loginData['be-ria'].username, loginData['be-ria'].password);
        let timeStartMetric = Date.now();
        await page.locator(mainToolBarObjects.QuickNavigation()).waitFor({ state: 'attached', timeout: 120000 });
        const metricTimeLogin = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.login", metricTimeLogin, events);
        await delay(STATIC_DELAY);

        // Navigation to new quote
        timeStartMetric = Date.now();
        const quickNavSearch = "Sales - Quotes";
        await page.locator(mainToolBarObjects.QuickNavigation()).click();
        await page.locator(mainToolBarObjects.QuickNavigation()).type(quickNavSearch, { delay: 100 });
        await page.getByRole('cell', { name: 'Select' }).click();
        await delay(2);
        await page.getByRole('cell', { name: 'New' }).click();
        await page.locator(objectPageObjects.InputTextBox("Customer")).waitFor({ state: 'attached', timeout: 120000 });
        const metricTime_1_1 = Date.now() - timeStartMetric - quickNavSearch.length * 100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.selection_quote", metricTime_1_1, events);
        await delay(STATIC_DELAY);

        // Search for a customer
        timeStartMetric = Date.now();
        await page.locator(objectPageObjects.InputTextBox("Customer")).click();
        await page.locator(objectPageObjects.InputTextBoxLens("Customer")).click();
        await page.locator(searchPageObjects.SelectionQuery()).waitFor({ state: 'visible' });
        await delay(1);
        await page.locator(searchPageObjects.SelectionQuery()).click();
        await page.locator(searchPageObjects.SelectionQueryArrowDown()).click();
        await delay(1);
        await page.getByText('Show All').click();
        await delay(1);
        await page.getByText('Find customer (B2B)').click();
        await page.locator(searchPageObjects.ConditionInputBox("Trading Name")).fill(userContext.vars.customer.toString());
        await page.locator(searchPageObjects.SearchButton()).click();
        await page.locator(searchPageObjects.ResultListItem(1)).dblclick();
        const metricTime_2_1 = Date.now() - timeStartMetric - 3000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.search_customer", metricTime_2_1, events);
        await delay(1);
        const exist = await page.getByRole('button', { name: 'New Request' }).isVisible({ timeout: 10000 });
        if (exist) {
            await page.getByRole('button', { name: 'New Request' }).click();
        }
        await delay(STATIC_DELAY);

        // Fill quote details
        // Quotation Template
        await page.locator(objectPageObjects.InputTextBox("Quotation Template")).click();
        await page.locator(objectPageObjects.DropDownSelectItem(scenarioData.QuotationTemplateMatrix)).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        const metricTime_2_2 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.quote_template", metricTime_2_2, events);

        // Driver
        await page.locator(objectPageObjects.InputTextBox("Driver")).click();
        await page.locator(objectPageObjects.InputTextBox("Driver")).fill(scenarioData.Driver)
        await page.locator(objectPageObjects.InputTextBox("Driver")).press("Enter");
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        await delay(STATIC_DELAY);

        // Make Model Type
        await InputMakeModeType(page, scenarioData.Make, scenarioData.Model, scenarioData.Type);
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        const metricTime_2_3 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.make_model_type", metricTime_2_3, events);
        await delay(STATIC_DELAY);

        // Stock/new + Duration and Distance
        timeStartMetric = Date.now();
        await InputNewStock(page, scenarioData['New/Stock']);
        await InputDurationDistance(page, scenarioData.Duration, scenarioData.Distance, 2, 100);
        const metricTime_2_4 = Date.now() - timeStartMetric - scenarioData.Duration.length * 100 - scenarioData.Distance.length * 100 - 2000;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.duration_distance_new", metricTime_2_4, events);
        await delay(STATIC_DELAY);

        // Add minimal equipment
        timeStartMetric = Date.now();
        await page.keyboard.press("F11");
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        await page.getByText('Z7Z7').click();
        await page.getByRole('link', { name: 'Add \'Metaalkleur\' (+545.46 EUR)' }).click();
        await page.getByRole('button', { name: 'Upholstery' }).click();
        await page.getByRole('listitem').filter({ hasText: 'YMZwart/zwart/zwart/titaangrijsUpholstery€ 0,00CO-BE-15Black' }).locator('span').click();
        await page.getByRole('button', { name: 'OK' }).click();
        const metricTime_2_5 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.min_equipment", metricTime_2_5, events);
        await delay(STATIC_DELAY);

        //Calculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate")).click();
        timeStartMetric = Date.now();
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        const metricTime_2_6 = Date.now() - timeStartMetric;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.calculate_quote", metricTime_2_6, events);
        await delay(STATIC_DELAY);

        //flexmatrix
        await page.locator("(//div[contains(text(),'Lease Service')])[1]").click();
        await page.locator("(//div[contains(text(),'Flex Matrix')])[1]").click();
        const metricTime_2_7 = Date.now() - timeStartMetric;
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.flexmatrix", metricTime_2_7, events);
        await delay(STATIC_DELAY);

        //matrix calculate
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Calculate Steps")).click();
        await page.locator("//td[@class='menuTitleField']//div[@role='presentation'][normalize-space()='Flex Matrix']").click();
        const metricTime_2_8 = Date.now() - timeStartMetric;
        await page.getByText("Loading...").waitFor({ state: 'hidden', timeout: 60000 });
        await page.locator(objectPageObjects.ObjectRibbonBarButton("Refresh"))
        captureCustomMetric(scenarioData.resultsFile, workerUUID, "nfr.flexmatrixcalculate", metricTime_2_8, events);
        await delay(900); //15min pause

        const totalTime = Date.now() - timeStart;
        captureCustomMetric(scenarioData.resultsFile, workerUUID, 'nfr.totalElapsedTime', totalTime, events);

    } catch (error) {
        await browser.tracing.stop({ path: `./traces/${workerUUID}.zip` });
        console.error(error);
        throw new Error('Whoops!');
    }
}

module.exports = { riaquotecreatematrix };