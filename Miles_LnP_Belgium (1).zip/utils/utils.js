const fs = require('fs');

function delay(timeout) {
    return new Promise((resolve) => {
        setTimeout(resolve, timeout * 1000);
    });
}

async function captureCustomMetric(file, workerUUID, metricName, metricTime, events) {
    const hostname = process.env.COMPUTERNAME;
    const filePath = file.replace("[HOSTNAME]", hostname)
    events.emit('histogram', metricName, metricTime);
    console.log(`${metricName}->${metricTime}`);
    fs.appendFileSync(filePath, `${workerUUID}, ${metricName}, ${metricTime}, ${Date.now()}\n`, { encoding: 'utf-8', flag: 'a' });
}

module.exports = { delay, captureCustomMetric };